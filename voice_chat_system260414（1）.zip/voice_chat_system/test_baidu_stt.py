# test_baidu_stt.py - 百度语音识别快速测试
import sys
import io
import speech_recognition as sr

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

from aip import AipSpeech


def test_baidu():
    APP_ID = "122835947"
    API_KEY = "ahebQ02XoLpKCyOZPbJq8A2B"
    SECRET_KEY = "bqgo8zrg7eF8BcZ1yYlXWJEx8hWAQEXn"

    print("=" * 50)
    print("  百度语音识别 (STT) 测试")
    print("=" * 50)

    # 初始化百度客户端
    client = AipSpeech(APP_ID, API_KEY, SECRET_KEY)
    print(f"[OK] 百度客户端初始化成功")

    # 麦克风设置
    r = sr.Recognizer()
    mic = sr.Microphone()

    with mic as source:
        r.adjust_for_ambient_noise(source, duration=1)
        print("\n[LISTEN] 请说一句话（10秒内）...")
        audio = r.listen(source, timeout=10, phrase_time_limit=8)

    # 转换为 PCM 格式（百度要求）
    raw_data = audio.get_raw_data(convert_rate=16000, convert_width=2)
    print(f"\n[PROCESS] 录音完成 ({len(raw_data)} bytes), 正在调用百度识别...")

    # 调用百度 ASR
    result = client.asr(raw_data, 'pcm', 16000, {
        'dev_pid': 1537,  # 普通话
    })

    if 'result' in result and result['result']:
        text = result['result'][0]
        print(f'\n[SUCCESS] 识别结果: "{text}"')
        print("[PASS] 百度语音识别完全正常! 可以启动主程序了!")
    elif 'error_code' in result:
        print(f'\n[ERROR] 错误码 {result["error_code"]}: {result.get("error_msg", "")}')
    else:
        print('\n[WARN] 未返回结果:', result)


if __name__ == "__main__":
    test_baidu()
