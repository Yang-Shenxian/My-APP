# ui/components.py - 独立UI组件（可复用控件）

from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout,
                             QPushButton, QLabel, QTextEdit, QFrame,
                             QScrollArea, QSlider)
from PyQt5.QtCore import Qt, QTimer, QEasingCurve, QPropertyAnimation, QSize
from PyQt5.QtGui import QColor, QPainter, QLinearGradient, QPaintEvent
import datetime


# ==================== AI 语音波形组件 ====================

class VoiceWaveform(QWidget):
    """
    AI 语音波形可视化组件 — 显示在视频窗口正上方。

    4 种状态：
      ① idle      → 浅灰色静态线条（待机）
      ② listening → 蓝色实时动态波形（随音量起伏）
      ③ thinking  → 紫色循环律动 + 光晕（思考）
      ④ speaking  → 青绿色同步波形（播报中）

    状态切换带平滑颜色过渡动画。
    """

    _STATE_CONFIG = {
        "idle": {
            "bg_color":       QColor(240, 241, 243),
            "wave_color":     QColor(200, 200, 210),
            "glow_color":     QColor(200, 200, 210, 0),
            "bar_count":      48,
            "static":         True,
        },
        "listening": {
            "bg_color":       QColor(232, 243, 253),
            "wave_color":     QColor(91, 155, 213),     # 柔和蓝 #5B9BD5
            "glow_color":     QColor(91, 155, 213, 30),
            "bar_count":      56,
            "static":         False,
        },
        "thinking": {
            "bg_color":       QColor(245, 238, 250),
            "wave_color":     QColor(139, 123, 200),    # 柔和紫 #8B7BC8
            "glow_color":     QColor(139, 123, 200, 35),
            "bar_count":      48,
            "static":         False,
        },
        "speaking": {
            "bg_color":       QColor(230, 246, 242),
            "wave_color":     QColor(82, 196, 166),     # 柔和青绿 #52C4A6
            "glow_color":     QColor(82, 196, 166, 30),
            "bar_count":      56,
            "static":         False,
        },
    }

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(72)
        self.setMinimumWidth(400)

        self._state = "idle"
        self._volume = 0.0          # 音量级别 0~1（listening 时由外部驱动）
        self._phase = 0.0           # 动画相位
        self._target_color = None   # 过渡目标颜色
        self._current_color = QColor(self._STATE_CONFIG["idle"]["wave_color"])
        self._target_bg = None
        self._current_bg = QColor(self._STATE_CONFIG["idle"]["bg_color"])
        self._transition_progress = 1.0  # 1.0=过渡完成
        self._prev_color = None

        # 动画定时器 ~50fps
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(20)

    # ---------- 公开 API ----------

    def set_state(self, state: str):
        """切换状态（触发平滑过渡动画）"""
        if state not in self._STATE_CONFIG:
            return
        if state == self._state:
            return
        cfg = self._STATE_CONFIG[state]
        self._prev_color = QColor(self._current_color)
        self._prev_bg = QColor(self._current_bg)
        self._target_color = QColor(cfg["wave_color"])
        self._target_bg = QColor(cfg["bg_color"])
        self._transition_progress = 0.0
        self._state = state
        # thinking/speaking 模式下重置相位
        if state in ("thinking", "speaking"):
            self._phase = 0.0

    def set_volume(self, level: float):
        """
        设置当前音频音量级别。
        :param level: 0.0 ~ 1.0（listening 模式下驱动波形振幅）
        """
        self._volume = max(0.0, min(1.0, level))

    # ---------- 内部动画 ----------

    def _tick(self):
        self._phase += 0.08
        if self._phase > 2 * 3.14159 * 100:
            self._phase -= 2 * 3.14159 * 100

        # 颜色过渡插值
        if self._transition_progress < 1.0:
            self._transition_progress += 0.05  # ~400ms 完成过渡
            if self._transition_progress >= 1.0:
                self._transition_progress = 1.0
                self._current_color = QColor(self._target_color) if self._target_color else self._current_color
                self._current_bg = QColor(self._target_bg) if self._target_bg else self._current_bg
            else:
                t = self._transition_progress
                # 缓动函数 ease-out-cubic
                et = 1 - (1 - t) ** 3
                self._current_color = self._lerp_color(self._prev_color, self._target_color, et)
                self._current_bg = self._lerp_color(self._prev_bg, self._target_bg, et)

        self.update()

    @staticmethod
    def _lerp_color(c1, c2, t):
        r = int(c1.red() + (c2.red() - c1.red()) * t)
        g = int(c1.green() + (c2.green() - c1.green()) * t)
        b = int(c1.blue() + (c2.blue() - c1.blue()) * t)
        a = int(c1.alpha() + (c2.alpha() - c1.alpha()) * t)
        return QColor(r, g, b, a)

    # ---------- 绘制 ----------

    def paintEvent(self, event: QPaintEvent):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        cfg = self._STATE_CONFIG[self._state]

        # ---- 背景 ----
        bg_grad = QLinearGradient(0, 0, 0, h)
        bg_grad.setColorAt(0, self._current_bg)
        darker = self._current_bg.darker(130)
        bg_grad.setColorAt(1, darker)
        p.setBrush(bg_grad)
        p.setPen(Qt.NoPen)
        p.drawRoundedRect(0, 0, w, h, 14, 14)

        # ---- 光晕层（thinking / speaking）----
        glow_alpha = int(cfg["glow_color"].alpha() * (0.5 + 0.5 * (self._phase % 3.14159) / 3.14159))
        if not cfg["static"] and glow_alpha > 5:
            glow = QColor(cfg["glow_color"])
            glow.setAlpha(glow_alpha)
            center_rect = w * 0.15, h * 0.15, w * 0.7, h * 0.7
            p.setBrush(glow)
            p.setPen(Qt.NoPen)
            p.drawRoundedRect(*center_rect, 18, 18)

        # ---- 波形条 ----
        bar_count = cfg["bar_count"]
        margin_x = int(w * 0.06)
        usable_w = w - margin_x * 2
        gap = max(2, usable_w / (bar_count + bar_count * 0.3))
        bar_width = max(2, gap * 0.6)
        base_y = h // 2

        for i in range(bar_count):
            cx = margin_x + int(i * (gap + bar_width))

            if cfg["static"]:
                # 待机：极简短线条
                bh = 3
                by = base_y - bh // 2
            elif self._state == "listening":
                # 聆听：随音量起伏的蓝色波形
                vol_factor = 0.15 + self._volume * 0.85
                noise = (self._phase * (i % 7 + 1) * 0.13) % 1.0
                wave = ((self._phase * 2.5 + i * 0.35) % 3.14159) / 3.14159  # 0~1
                # 中间高、两边低的包络
                env = 1.0 - abs(i - bar_count / 2) / (bar_count / 2) * 0.65
                bh = int((4 + wave * (h * 0.32) * vol_factor * env + noise * 4))
                bh = max(3, min(bh, int(h * 0.38)))
                by = base_y - bh // 2
            elif self._state == "thinking":
                # 思考：紫色循环律动
                pulse = (self._phase * 1.8 + i * 0.22) % 6.28318
                wave_val = (pulse % 3.14159) / 3.14159  # 0~1 半波
                env = 1.0 - abs(i - bar_count / 2) / (bar_count / 2) * 0.5
                bh = int(4 + wave_val * (h * 0.30) * env)
                bh = max(3, min(bh, int(h * 0.36)))
                by = base_y - bh // 2
            else:  # speaking
                # 播报：青绿色节奏波形（模拟语音节奏）
                beat = (self._phase * 3.0 + i * 0.18) % 6.28318
                wave_val = abs(beat % 3.14159 - 1.57) / 1.57  # 三角波 0~1
                env = 1.0 - abs(i - bar_count / 2) / (bar_count / 2) * 0.55
                # 加入轻微随机变化模拟语音自然感
                rand_var = (i * 7 & 0xF) / 16.0 * 0.15
                bh = int(4 + wave_val * (h * 0.34) * env * (0.75 + rand_var))
                bh = max(3, min(bh, int(h * 0.38)))
                by = base_y - bh // 2

            # 渐变色条（顶部亮、底部暗）
            bar_grad = QLinearGradient(cx, by, cx, by + bh)
            top_c = self._current_color.lighter(120)
            bot_c = self._current_color.darker(130)
            bar_grad.setColorAt(0, top_c)
            bar_grad.setColorAt(1, bot_c)
            p.setBrush(bar_grad)
            p.setPen(Qt.NoPen)
            # 圆角小矩形
            radius = max(int(bar_width / 2), 2)
            p.drawRoundedRect(int(cx), int(by), int(bar_width), int(bh), radius, radius)

        p.end()


# ==================== 聊天气泡组件 ====================

class ChatBubble(QFrame):
    """聊天气泡 - 独立的 Widget，自适应内容宽度（支持深色/浅色）"""

    _THEMES = {
        "light": {
            "user_bg": "#E3F0FD", "user_text": "#1A365D",
            "ai_bg": "#F5F5F5", "ai_text": "#333333",
        },
        "dark": {
            "user_bg": "#1A2E48", "user_text": "#B8D4F0",
            "ai_bg": "#2A2B2F", "ai_text": "#E4E4E7",
        },
    }

    def __init__(self, text, role="user", parent=None, theme_name="light"):
        super().__init__(parent)
        self.role = role
        self._text = text
        self._theme_name = theme_name
        self._setup_ui()

    def set_theme(self, theme_name):
        """更新气泡主题"""
        if theme_name == self._theme_name:
            return
        self._theme_name = theme_name
        t = self._THEMES.get(theme_name, self._THEMES["light"])
        if self.role == "user":
            bg, text_color = t["user_bg"], t["user_text"]
        else:
            bg, text_color = t["ai_bg"], t["ai_text"]
        for child in self.findChildren(QLabel):
            if child.objectName() in ("userBubble", "aiBubble"):
                child.setStyleSheet(f"""
                    QLabel#{child.objectName()} {{
                        background-color: {bg};
                        color: {text_color};
                        padding: 10px 14px;
                        border-radius: 12px;
                        font-size: 13px;
                        line-height: 1.6;
                    }}
                """)
                break

    def _setup_ui(self):
        self.setContentsMargins(0, 6, 0, 6)

        outer = QHBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)

        if self.role == "user":
            outer.addStretch(3)
            inner = QVBoxLayout()
            inner.setContentsMargins(4, 2, 8, 2)
            bubble = QLabel(self._text)
            bubble.setObjectName("userBubble")
            bubble.setStyleSheet("""
                QLabel#userBubble {
                    background-color: #E3F0FD;
                    color: #1A365D;
                    padding: 10px 14px;
                    border-radius: 12px;
                    font-size: 13px;
                    line-height: 1.6;
                }
            """)
            bubble.setWordWrap(True)
            bubble.setMaximumWidth(int(self._max_bubble_width()))
            inner.addWidget(bubble)
            outer.addLayout(inner)
        else:
            inner = QVBoxLayout()
            inner.setContentsMargins(8, 2, 4, 2)
            bubble = QLabel(self._text)
            bubble.setObjectName("aiBubble")
            bubble.setStyleSheet("""
                QLabel#aiBubble {
                    background-color: #F5F5F5;
                    color: #333333;
                    padding: 10px 14px;
                    border-radius: 12px;
                    font-size: 13px;
                    line-height: 1.6;
                }
            """)
            bubble.setWordWrap(True)
            bubble.setMaximumWidth(int(self._max_bubble_width()))
            inner.addWidget(bubble)
            outer.addLayout(inner)
            outer.addStretch(3)

    def _max_bubble_width(self):
        return 380

    def update_text(self, new_text):
        """更新气泡文字（用于打字机效果）"""
        self._text = new_text
        for child in self.findChildren(QLabel):
            if child.objectName() in ("userBubble", "aiBubble"):
                child.setText(new_text)
                return


class ThinkingIndicator(QWidget):
    """思考动画 - 三个跳动的小点（支持深色/浅色）"""

    def __init__(self, parent=None, dot_color=None):
        super().__init__(parent)
        self.phase = 0
        self._dot_color = dot_color or QColor(160, 150, 200)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._tick)
        self.timer.start(280)

        self.setFixedHeight(50)
        self.setMinimumWidth(120)

    def set_theme_dot_color(self, color):
        """设置主题颜色"""
        self._dot_color = QColor(color)
        self.update()

    def _tick(self):
        self.phase = (self.phase + 1) % 6
        self.update()

    def paintEvent(self, event: QPaintEvent):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        dot_color = self._dot_color
        dot_r = 5
        spacing = 22

        total_w = spacing * 2 + dot_r * 2
        start_x = (self.width() - total_w) // 2
        cy = self.height() // 2

        offsets = [
            [0, -8, 0], [2, -14, 2], [6, -6, 6],
            [10, 0, 10], [6, -2, 6], [2, -6, 2],
        ]
        offset = offsets[self.phase]

        for i in range(3):
            cx = start_x + i * spacing + dot_r
            dy = offset[i]
            painter.setBrush(dot_color)
            painter.setPen(Qt.NoPen)
            painter.drawEllipse(cx, cy + dy - dot_r, dot_r * 2, dot_r * 2)

        painter.end()

    def stop(self):
        self.timer.stop()


class TypingBubble(QFrame):
    """打字输出气泡 - 可动态更新文字（支持深色/浅色）"""

    _THEMES = {
        "light": {"bg": "#f3edfa", "text": "#3d3058"},
        "dark":  {"bg": "#2D2242", "text": "#B4A8D4"},
    }

    def __init__(self, parent=None, theme_name="light"):
        super().__init__(parent)
        self._theme_name = theme_name
        self.setContentsMargins(8, 6, 4, 6)
        t = self._THEMES.get(theme_name, self._THEMES["light"])
        layout = QHBoxLayout(self)
        layout.addLayout(
            self._build_bubble_layout("", "aiBubble", t["bg"], t["text"])
        )
        layout.addStretch()
        self.label = self.findChild(QLabel, "aiBubble")

    def set_theme(self, theme_name):
        if theme_name == self._theme_name:
            return
        self._theme_name = theme_name
        t = self._THEMES.get(theme_name, self._THEMES["light"])
        for child in self.findChildren(QLabel):
            if child.objectName() == "aiBubble":
                child.setStyleSheet(f"""
                    QLabel#aiBubble {{
                        background-color: {t['bg']};
                        color: {t['text']};
                        padding: 10px 14px;
                        border-radius: 12px;
                        font-size: 13px;
                        line-height: 1.6;
                    }}
                """)
                break

    @staticmethod
    def _build_bubble_layout(text, name, bg_color, text_color):
        inner = QVBoxLayout()
        inner.setContentsMargins(4, 2, 8, 2)
        lbl = QLabel(text)
        lbl.setObjectName(name)
        lbl.setStyleSheet(f"""
            QLabel#{name} {{
                background-color: {bg_color};
                color: {text_color};
                padding: 10px 14px;
                border-radius: 12px;
                font-size: 13px;
                line-height: 1.6;
            }}
        """)
        lbl.setWordWrap(True)
        lbl.setMaximumWidth(380)
        inner.addWidget(lbl)
        return inner

    def set_partial_text(self, text):
        self.label.setText(text)


class CardPanel(QFrame):
    """卡片面板 — 样式由全局 QSS 统一管理（支持 light/dark 主题切换）"""

    def __init__(self, parent=None):
        super().__init__(parent)


class StatusIndicator(QLabel):
    """状态指示器 - 支持动态主题切换"""

    def __init__(self):
        super().__init__("待机中")
        self.setAlignment(Qt.AlignCenter)
        self._theme_data = None

    def set_theme(self, theme_dict):
        """从外部接收当前主题配色"""
        self._theme_data = theme_dict

    def _get_status_style(self, status):
        """根据当前主题获取状态样式 (text, color, bg)"""
        t = self._theme_data
        if not t:
            # 无主题数据时回退默认浅色
            return {
                "idle":     ("待机中",   "#B8860B", "#FFF8E8"),
                "listening":("正在聆听...","#2B6CB0","#EBF4FC"),
                "thinking": ("AI思考中...","#6A5DA0","#F3EEFB"),
                "speaking": ("AI回复中...","#2E7D32","#EDF7EC"),
            }.get(status, ("待机中", "#B8860B", "#FFF8E8"))
        return {
            "idle":     ("待机中",   t.get("status_idle_text"),  t.get("status_idle_bg")),
            "listening":("正在聆听...",t.get("status_listen_text"), t.get("status_listen_bg")),
            "thinking": ("AI思考中...",t.get("status_think_text"),  t.get("status_think_bg")),
            "speaking": ("AI回复中...",t.get("status_speak_text"),  t.get("status_speak_bg")),
        }.get(status, ("待机中", t.get("text_primary", "#333333"), t.get("card_bg", "#FFFFFF")))

    def set_status(self, status):
        self._current_status = status
        text, color, bg = self._get_status_style(status)
        self.setText(text)
        self.setStyleSheet(f"""
            QLabel {{
                font-size: 13px;
                font-weight: 600;
                color: {color};
                background-color: {bg};
                padding: 8px 20px;
                border-radius: 20px;
                min-height: 18px;
            }}
        """)


# ==================== 日志面板组件 ====================

class LogPanel(QFrame):
    """
    可折叠/展开的运行日志面板 — 支持主题切换

    功能：
      - 按类型分类显示日志（系统/语音/AI/错误）
      - 支持自动滚动到底部
      - 一键清空 / 日志过滤 / 收起展开
      - 默认高度100px，支持拖拽调整
    """

    # 浅色模式日志类型配色
    LOG_STYLES_LIGHT = {
        "system": {"prefix": "[系统]", "color": "#4A9D5C"},
        "voice":  {"prefix": "[语音]", "color": "#4B8BC2"},
        "ai":     {"prefix": "[AI]",   "color": "#8B6DB8"},
        "error":  {"prefix": "[错误]", "color": "#D4535A"},
        "info":   {"prefix": "[信息]", "color": "#999999"} ,
    }

    # 深色模式日志类型配色（稍亮一些适配深底）
    LOG_STYLES_DARK = {
        "system": {"prefix": "[系统]", "color": "#6BC47A"},
        "voice":  {"prefix": "[语音]", "color": "#63A3E0"},
        "ai":     {"prefix": "[AI]",   "color": "#B4A8D4"},
        "error":  {"prefix": "[错误]", "color": "#E57373"},
        "info":   {"prefix": "[信息]", "color": "#A1A1AA"} ,
    }

    @property
    def LOG_STYLES(self):
        return self.LOG_STYLES_DARK if getattr(self, '_is_dark', False) else self.LOG_STYLES_LIGHT

    def __init__(self, parent=None):
        super().__init__(parent)
        self._collapsed = False  # 不使用内部折叠，由外部 show/hide 控制
        self._default_height = 100
        self._expanded_height = 200
        self._filter_type = "all"  # all / system / voice / ai / error
        self._log_entries = []  # 所有日志条目 [(type, text, time)]
        self._is_dark = False
        self._setup_ui()

    def set_theme(self, is_dark):
        """切换日志面板主题（深色/浅色）"""
        if self._is_dark == is_dark:
            return
        self._is_dark = is_dark
        bg_color = "#1E1F22" if is_dark else "#FFFFFF"
        text_color = "#A1A1AA" if is_dark else "#666666"
        border_style = "1px solid rgba(255,255,255,0.07)" if is_dark else "1px solid rgba(0,0,0,0.06)"
        # 刷新面板背景
        self.setStyleSheet(f"""
            QFrame#logPanel {{
                background-color: {bg_color};
                border-radius: 10px;
                border: {border_style};
            }}
        """)
        # 刷新日志文本区
        if hasattr(self, 'log_text'):
            self.log_text.setStyleSheet(f"""
                QTextEdit#logText {{
                    background: transparent;
                    color: {text_color};
                    font-family: "Consolas", "Microsoft YaHei", monospace;
                    font-size: 11px;
                    border: none;
                    selection-background-color: {"rgba(150,130,200,0.2)" if is_dark else "rgba(90,77,140,0.12)"};
                }}
            """)
        # 重建日志显示内容
        self.log_text.clear()
        for lt, msg, ts in self._log_entries:
            if self._should_show(lt):
                style = self.LOG_STYLES.get(lt, self.LOG_STYLES["info"])
                line = f'<span style="color:{style["color"]}">{style["prefix"]}</span> <span style="color:{"#888" if is_dark else "#555555"}">{msg}</span>'
                self.log_text.append(line)

    def _setup_ui(self):
        self.setObjectName("logPanel")
        self.setFixedHeight(self._default_height)
        self.setStyleSheet("""
            QFrame#logPanel {
                background-color: #FFFFFF;
                border-radius: 10px;
                border: 1px solid rgba(0, 0, 0, 0.06);
            }
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 6, 10, 6)
        layout.setSpacing(4)

        # ---- 工具栏 ----
        toolbar = QHBoxLayout()
        toolbar.setSpacing(8)

        title_lbl = QLabel("运行日志")
        title_lbl.setStyleSheet("color:#555555; font-size:12px; font-weight:600;")
        toolbar.addWidget(title_lbl)

        toolbar.addStretch()

        # 过滤按钮
        self._filter_btn = QPushButton("全部")
        self._filter_btn.setFixedSize(56, 24)
        self._filter_btn.setStyleSheet("""
            QPushButton { background: #F0EDFA; color:#5A4D8C;
                         border-radius:6px; font-size:11px; padding:2px 8px;
                         border:1px solid rgba(90,77,140,0.1); }
            QPushButton:hover { background: #E4DDF3; }
        """)
        self._filter_btn.setCursor(Qt.PointingHandCursor)
        self._filter_btn.clicked.connect(self._cycle_filter)
        toolbar.addWidget(self._filter_btn)

        # 清空按钮
        clear_btn = QPushButton("清空")
        clear_btn.setFixedSize(46, 24)
        clear_btn.setStyleSheet("""
            QPushButton { background: rgba(244,67,54,0.08); color:#D4535A;
                         border-radius:6px; font-size:11px; padding:2px 8px;
                         border:1px solid rgba(212,83,90,0.15); }
            QPushButton:hover { background: rgba(244,67,54,0.15); }
        """)
        clear_btn.setCursor(Qt.PointingHandCursor)
        clear_btn.clicked.connect(self.clear_logs)
        toolbar.addWidget(clear_btn)

        # 复制按钮
        copy_btn = QPushButton("复制")
        copy_btn.setFixedSize(46, 24)
        copy_btn.setStyleSheet("""
            QPushButton { background: rgba(43,108,176,0.08); color:#2B6CB0;
                         border-radius:6px; font-size:11px; padding:2px 8px;
                         border:1px solid rgba(43,108,176,0.15); }
            QPushButton:hover { background: rgba(43,108,176,0.15); }
        """)
        copy_btn.setCursor(Qt.PointingHandCursor)
        copy_btn.clicked.connect(self.copy_logs)
        toolbar.addWidget(copy_btn)

        layout.addLayout(toolbar)

        # ---- 日志文本区 ----
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setObjectName("logText")
        self.log_text.setMinimumHeight(50)
        self.log_text.setStyleSheet("""
            QTextEdit#logText {
                background: transparent;
                color: #666666;
                font-family: "Consolas", "Microsoft YaHei", monospace;
                font-size: 11px;
                border: none;
                selection-background-color: rgba(90, 77, 140, 0.12);
            }
        """)
        layout.addWidget(self.log_text, 1)

        # 初始欢迎信息
        self._append_log_entry("info", "🌟 小智已上线，说「小智」就可以唤醒我哦～")

    def append_log(self, log_type, message):
        """
        添加日志条目。
        :param log_type: "system" | "voice" | "ai" | "error" | "info"
        :param message: 日志文字
        """
        now = datetime.datetime.now().strftime("%H:%M:%S")
        self._log_entries.append((log_type, message, now))
        if self._should_show(log_type):
            style = self.LOG_STYLES.get(log_type, self.LOG_STYLES["info"])
            colored_line = f'<span style="color:{style["color"]}">{style["prefix"]}</span> <span style="color:#555555">{message}</span>'
            self.log_text.append(colored_line)
            # 自动滚底
            sb = self.log_text.verticalScrollBar()
            sb.setValue(sb.maximum())

    def _should_show(self, log_type):
        """当前过滤条件下是否应该显示该类型"""
        return (self._filter_type == "all") or (self._filter_type == log_type)

    def clear_logs(self):
        """清空所有日志"""
        self._log_entries.clear()
        self.log_text.clear()
        self._append_log_entry("info", "日志已清空")

    def copy_logs(self):
        """将所有日志复制到剪贴板（纯文本格式）"""
        lines = []
        for lt, msg, ts in self._log_entries:
            style = self.LOG_STYLES.get(lt, self.LOG_STYLES["info"])
            lines.append(f"[{ts}] {style['prefix']} {msg}")
        text = "\n".join(lines) if lines else "（无日志）"
        from PyQt5.QtWidgets import QApplication
        QApplication.clipboard().setText(text)
        # 短暂提示
        self._append_log_entry("info", f"已复制 {len(lines)} 条日志到剪贴板")

    def toggle(self):
        """切换收起/展开"""
        if self._collapsed:
            self._expand()
        else:
            self._collapse()

    def _collapse(self):
        """收起到最小高度（隐藏日志文本区）"""
        self._collapsed = True
        self._toggle_btn.setText("展开 ▴")
        self._expanded_height = max(self.height(), self._default_height)
        # 关键：隐藏文本区以突破 minimumHeight 限制
        self.log_text.hide()
        self.animate_to_height(32)  # 只留工具栏

    def _expand(self):
        """展开到之前的高度（恢复显示日志文本区）"""
        self._collapsed = False
        self._toggle_btn.setText("收起 ▾")
        target = max(self._expanded_height, self._default_height)
        self.animate_to_height(target)
        # 动画结束后显示文本区
        QTimer.singleShot(280, lambda: self.log_text.show())

    def animate_to_height(self, target_h):
        """动画过渡到目标高度"""
        anim = QPropertyAnimation(self, b"minimumHeight")
        anim.setDuration(250)
        anim.setEasingCurve(QEasingCurve.OutCubic)
        anim.setStartValue(self.height())
        anim.setEndValue(int(target_h))

        anim2 = QPropertyAnimation(self, b"maximumHeight")
        anim2.setDuration(250)
        anim2.setEasingCurve(QEasingCurve.OutCubic)
        anim2.setStartValue(self.height())
        anim2.setEndValue(int(target_h))

        def _on_finish():
            self.setFixedHeight(int(target_h))
            self.setMinimumSize(QSize(0, 0))
            self.setMaximumSize(QSize(16777215, 16777215))

        anim.finished.connect(_on_finish)
        anim.start()
        anim2.start()

    def _cycle_filter(self):
        """循环切换过滤模式"""
        filters = ["all", "system", "voice", "ai", "error"]
        names = {"all": "全部", "system": "系统", "voice": "语音", "ai": "AI", "error": "错误"}
        idx = filters.index(self._filter_type) if self._filter_type in filters else 0
        self._filter_type = filters[(idx + 1) % len(filters)]
        self._filter_btn.setText(names[self._filter_type])
        # 重建显示内容
        self.log_text.clear()
        for lt, msg, ts in self._log_entries:
            if self._should_show(lt):
                style = self.LOG_STYLES.get(lt, self.LOG_STYLES["info"])
                line = f'<span style="color:{style["color"]}">{style["prefix"]}</span> <span style="color:#555555">{msg}</span>'
                self.log_text.append(line)

    def _append_log_entry(self, log_type, message):
        """内部方法：直接追加一条格式化日志"""
        style = self.LOG_STYLES.get(log_type, self.LOG_STYLES["info"])
        line = f'<span style="color:{style["color"]}">{style["prefix"]}</span> <span style="color:#555555">{message}</span>'
        self.log_text.append(line)


# ==================== 轻量通知弹窗 ====================

class ToastNotification(QWidget):
    """
    轻量级自动消失通知弹窗

    用法：ToastNotification.notify(parent, "消息文本", level="success"/"warning"/"error")
    3秒后自动消失，带淡入淡出动画
    """

    LEVEL_STYLES = {
        "success": ("成功", "#4A9D5C", "rgba(236,248,240,0.97)", "#2E7D32"),
        "warning": ("提示", "#B8860B", "rgba(255,249,235,0.97)", "#9A7209"),
        "error":   ("错误", "#D4535A", "rgba(255,238,238,0.97)", "#B33A41"),
        "info":    ("信息", "#4B8BC2", "rgba(235,244,252,0.97)", "#2B6CB0"),
    }

    @staticmethod
    def notify(parent, message, level="info", duration=3000):
        """工厂方法：创建并显示一个通知"""
        toast = ToastNotification(parent, message, level, duration)
        toast._appear()

    def __init__(self, parent, message, level="info", duration=3000):
        super().__init__(parent)
        self._parent_win = parent.window() if hasattr(parent, 'window') else parent
        self.setAttribute(Qt.WA_TranslucentBackground)
        # 不使用 WindowStaysOnTopHint，避免浮在所有应用之上
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Tool)
        self.message = message
        self.duration = duration
        self.level_style = self.LEVEL_STYLES.get(level, self.LEVEL_STYLES["info"])

        _, title_text, bg_color, border_color = self.level_style

        # 固定宽度，自适应高度
        self.setFixedWidth(360)
        label = QLabel(message)
        label.setWordWrap(True)
        label.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        label.setStyleSheet(f"""
            QLabel {{
                color: {border_color}; font-size:13px; padding:12px 16px;
                background: transparent;
            }}
        """)
        self._label = label

        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(label)

        self.setStyleSheet(f"""
            ToastNotification {{
                background-color: {bg_color};
                border-radius: 10px;
                border-left: 3px solid {border_color};
            }}
        """)

    def _appear(self):
        """淡入出现 + 定时消失"""
        # 定位在父窗口顶部中央偏右
        if self._parent_win:
            pw = self._parent_win.width()
            ph = self._parent_win.geometry().y()
            x = self._parent_win.x() + pw - self.width() - 20
            y = self._parent_win.y() + 70
            self.move(x, y)

        # 淡入效果
        self._opacity_anim = QPropertyAnimation(self, b"windowOpacity")
        self._opacity_anim.setDuration(300)
        self._opacity_anim.setStartValue(0.0)
        self._opacity_anim.setEndValue(1.0)
        self._opacity_anim.finished.connect(lambda: QTimer.singleShot(self.duration, self._fade_out))
        self._opacity_anim.start()

        self.show()
        self.raise_()

    def _fade_out(self):
        """淡出消失"""
        fade = QPropertyAnimation(self, b"windowOpacity")
        fade.setDuration(400)
        fade.setStartValue(1.0)
        fade.setEndValue(0.0)
        fade.finished.connect(self.close)
        fade.start()
