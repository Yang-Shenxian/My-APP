# ui/main_window.py - 主窗口（视频为主，隐藏式侧边栏）

from PyQt5.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                             QPushButton, QLabel, QTextEdit, QLineEdit,
                             QComboBox, QFileDialog, QTabWidget,
                             QSpinBox, QMessageBox, QFrame, QScrollArea,
                             QGraphicsDropShadowEffect, QSplitter, QSlider,
                             QDialog)
from PyQt5.QtCore import Qt, QTimer, pyqtSignal, QEasingCurve, QPropertyAnimation, pyqtSlot, QAbstractAnimation, QPoint, QRectF, QSize
from PyQt5.QtGui import QFont, QPixmap, QColor, QPainter, QIcon, QPaintEvent, QCursor, QImage
import os
import threading
import cv2
import platform

# 从独立组件模块导入所有UI控件
from ui.components import (
    VoiceWaveform, ChatBubble, ThinkingIndicator, TypingBubble,
    CardPanel, StatusIndicator, LogPanel
)
from config import Config


# ==================== 主题配色方案 ====================

THEMES = {
    "light": {
        # 全局
        "main_bg":              "#F8F9FA",
        "dialog_bg":            "#F8F9FA",
        "text_primary":         "#333333",
        "text_secondary":       "#666666",
        "text_muted":           "#999999",
        "border_color":         "#E0E0E4",
        "border_light":         "rgba(0, 0, 0, 0.06)",
        "card_bg":              "rgba(255, 255, 255, 0.92)",
        "card_border":          "1px solid rgba(0, 0, 0, 0.06)",
        "input_bg":             "#FFFFFF",
        "input_focus_border":   "#B8A9DA",
        "input_hover_border":   "#CCC8DB",

        # 按钮 — 紫色系
        "btn_bg":               "#EEEAF6",
        "btn_text":             "#5A4D8C",
        "btn_border":           "rgba(90, 77, 140, 0.15)",
        "btn_hover":            "#E4DDF3",
        "btn_pressed":          "#DDD2EE",
        "btn_disabled_bg":      "#F0F0F0",
        "btn_disabled_text":    "#BBBBBB",
        "btn_disabled_border":  "#EEEEEE",

        # 按钮 — 蓝色(primary)
        "btn_primary_bg":       "#E3F0FD",
        "btn_primary_text":     "#2B6CB0",
        "btn_primary_border":   "rgba(43, 108, 176, 0.15)",
        "btn_primary_hover":    "#D4E5F8",

        # 按钮 — 红色(danger)
        "btn_danger_bg":        "#FFECEF",
        "btn_danger_text":      "#C0392B",
        "btn_danger_border":    "rgba(192, 57, 43, 0.15)",
        "btn_danger_hover":     "#FFDCDF",

        # 按钮 — 黄色(warning)
        "btn_warning_bg":       "#FFF4E0",
        "btn_warning_text":     "#B8860B",
        "btn_warning_border":   "rgba(184, 134, 11, 0.15)",
        "btn_warning_hover":    "#FFECC8",

        # 滚动条
        "scrollbar_handle":     "#D4CFE0",
        "scrollbar_hover":      "#C4BBDA",

        # 视频区
        "video_bg":             "#F0F1F3",
        "video_text":           "#888888",

        # 侧边栏
        "sidepanel_bg":         "#FFFFFF",
        "sidepanel_border":     "1px solid rgba(0, 0, 0, 0.08)",

        # FAB悬浮按钮
        "fab_bg":               "#FFFFFF",
        "fab_text":             "#5A4D8C",
        "fab_border":           "1px solid rgba(0, 0, 0, 0.08)",
        "fab_hover_bg":         "#F5F2FC",
        "fab_hover_border":     "rgba(90, 77, 140, 0.2)",

        # 底部菜单栏
        "bottombar_bg":         "#EDEEF0",

        # 聊天区
        "chat_scroll_bg":       "#FAFBFC",
        "chat_input_bg":        "#FFFFFF",
        "chat_input_border":    "1px solid rgba(0, 0, 0, 0.06)",

        # 日志面板
        "log_panel_bg":         "#FFFFFF",
        "log_text":             "#666666",

        # Tooltip
        "tooltip_bg":           "#444444",
        "tooltip_text":         "#FFFFFF",

        # 下拉箭头
        "combo_arrow":          "#8B7BC8",
        "combo_dropdown_bg":    "#FFFFFF",
        "combo_dropdown_selbg": "#F0EDFA",

        # 发送按钮
        "send_btn_bg":          "#EEEAF6",
        "send_btn_text":        "#5A4D8C",
        "send_btn_border":      "1px solid rgba(90, 77, 140, 0.15)",
        "send_btn_hover":       "#E4DDF3",
        "send_btn_pressed":     "#DDD2EE",

        # 设置保存按钮
        "save_btn_bg":          "#5A4D8C",
        "save_btn_hover":       "#6A5DA0",
        "save_btn_pressed":     "#4D4177",

        # 侧边栏头部
        "header_bg":            "#FFFFFF",
        "header_border":        "1px solid rgba(0, 0, 0, 0.06)",
        "header_title":         "#333333",
        "close_btn_hover_bg":   "rgba(200,50,50,0.08)",
        "close_btn_hover_text": "#C0392B",

        # 分隔线颜色
        "separator":            "#E0E0E4",

        # 选中背景
        "selection_bg":         "#EDE8FA",

        # 状态标签
        "status_idle_bg":       "#FFF8E8",
        "status_idle_text":     "#B8860B",
        "status_listen_bg":     "#EBF4FC",
        "status_listen_text":   "#2B6CB0",
        "status_think_bg":      "#F3EEFB",
        "status_think_text":    "#6A5DA0",
        "status_speak_bg":      "#EDF7EC",
        "status_speak_text":    "#2E7D32",

        # 音色标签
        "voice_label_bg":       "rgba(90, 77, 140, 0.06)",
        "voice_label_text":     "#5A4D8C",
        "voice_label_fw":       "600",

        # API状态
        "api_ok_color":         "#66BB6A",
        "api_err_color":        "#E07070",

        # 搜索状态
        "search_doing_color":   "#5B9BD5",
        "search_done_color":    "#66BB6A",

        # 关闭按钮
        "close_btn_text_def":   "#999999",
    },

    "dark": {
        # 全局
        "main_bg":              "#121315",
        "dialog_bg":            "#16171A",
        "text_primary":         "#E4E4E7",
        "text_secondary":       "#A1A1AA",
        "text_muted":           "#71717A",
        "border_color":         "#4A4D58",
        "border_light":         "rgba(255, 255, 255, 0.10)",
        "card_bg":              "#262A34",
        "card_border":          "1px solid rgba(255, 255, 255, 0.12)",
        "input_bg":             "#303442",
        "input_focus_border":   "#8E7DBC",
        "input_hover_border":   "#505464",

        # 按钮 — 紫色系（深色调）
        "btn_bg":               "#2D2242",
        "btn_text":             "#B4A8D4",
        "btn_border":           "rgba(150, 130, 200, 0.18)",
        "btn_hover":            "#382C52",
        "btn_pressed":          "#241A36",
        "btn_disabled_bg":      "#1E2027",
        "btn_disabled_text":    "#555566",
        "btn_disabled_border":  "#303442",

        # 按钮 — 蓝色(primary)
        "btn_primary_bg":       "#1A2E48",
        "btn_primary_text":     "#63A3E0",
        "btn_primary_border":   "rgba(99, 163, 224, 0.15)",
        "btn_primary_hover":    "#233A58",

        # 按钮 — 红色(danger)
        "btn_danger_bg":        "#3D1E24",
        "btn_danger_text":      "#E57373",
        "btn_danger_border":    "rgba(229, 115, 115, 0.15)",
        "btn_danger_hover":     "#4D262E",

        # 按钮 — 黄色(warning)
        "btn_warning_bg":       "#3D3018",
        "btn_warning_text":     "#D4A84B",
        "btn_warning_border":   "rgba(212, 168, 75, 0.15)",
        "btn_warning_hover":    "#4D3C20",

        # 滚动条
        "scrollbar_handle":     "#3E4150",
        "scrollbar_hover":      "#505464",

        # 视频区
        "video_bg":             "#1B1D22",
        "video_text":           "#6B6B75",

        # 侧边栏
        "sidepanel_bg":         "#1B1D22",
        "sidepanel_border":     "1px solid rgba(255, 255, 255, 0.10)",

        # FAB悬浮按钮
        "fab_bg":               "#282B34",
        "fab_text":             "#B4A8D4",
        "fab_border":           "1px solid rgba(255, 255, 255, 0.12)",
        "fab_hover_bg":         "#33364A",
        "fab_hover_border":     "rgba(150, 130, 200, 0.2)",

        # 底部菜单栏
        "bottombar_bg":         "#1E2027",

        # 聊天区
        "chat_scroll_bg":       "#1B1D22",
        "chat_input_bg":        "#303442",
        "chat_input_border":    "1px solid rgba(255, 255, 255, 0.12)",

        # 日志面板
        "log_panel_bg":         "#1B1D22",
        "log_text":             "#A1A1AA",

        # Tooltip
        "tooltip_bg":           "#E4E4E7",
        "tooltip_text":         "#1A1B1E",

        # 下拉箭头
        "combo_arrow":          "#B4A8D4",
        "combo_dropdown_bg":    "#303442",
        "combo_dropdown_selbg": "#3D3558",

        # 发送按钮
        "send_btn_bg":          "#2D2242",
        "send_btn_text":        "#B4A8D4",
        "send_btn_border":      "1px solid rgba(150, 130, 200, 0.18)",
        "send_btn_hover":       "#382C52",
        "send_btn_pressed":     "#241A36",

        # 设置保存按钮
        "save_btn_bg":          "#7C6BA8",
        "save_btn_hover":       "#8E7DBC",
        "save_btn_pressed":     "#6A5A96",

        # 侧边栏头部
        "header_bg":            "#1B1D22",
        "header_border":        "1px solid rgba(255, 255, 255, 0.10)",
        "header_title":         "#E4E4E7",
        "close_btn_hover_bg":   "rgba(220, 80, 80, 0.12)",
        "close_btn_hover_text": "#E57373",

        # 分隔线颜色
        "separator":            "#3A3D48",

        # 选中背景
        "selection_bg":         "#2D2242",

        # 状态标签
        "status_idle_bg":       "#3D3018",
        "status_idle_text":     "#D4A84B",
        "status_listen_bg":     "#1A2E48",
        "status_listen_text":   "#63A3E0",
        "status_think_bg":      "#2D2242",
        "status_think_text":    "#B4A8D4",
        "status_speak_bg":      "#1E3D22",
        "status_speak_text":    "#6BC47A",

        # 音色标签
        "voice_label_bg":       "rgba(150, 130, 200, 0.12)",
        "voice_label_text":     "#B4A8D4",
        "voice_label_fw":       "600",

        # API状态
        "api_ok_color":         "#6BC47A",
        "api_err_color":        "#E57373",

        # 搜索状态
        "search_doing_color":   "#63A3E0",
        "search_done_color":    "#6BC47A",

        # 关闭按钮
        "close_btn_text_def":   "#71717A",
    },
}


class MainWindow(QMainWindow):
    """主窗口界面 — 视频为主，隐藏式侧边栏"""

    text_chat_signal = pyqtSignal(str)
    _typewriter_signal = pyqtSignal(str)

    def __init__(self, controller):
        super().__init__()
        self.controller = controller
        self._typewriter_signal.connect(self._start_typewriter)
        self._theme_name = "light"  # 当前主题: "light" | "dark"
        self.init_ui()

    # ==================== 布局初始化 ====================

    def _apply_global_stylesheet(self):
        """根据当前 _theme_name 生成并应用全局 QSS 样式表"""
        t = THEMES.get(self._theme_name, THEMES["light"])
        ss = f"""
            QMainWindow {{
                background-color: {t["main_bg"]};
            }}
            * {{
                font-family: "Microsoft YaHei", "PingFang SC", sans-serif;
                outline: none;
            }}

            CardPanel {{
                background-color: {t["card_bg"]};
                border-radius: 10px;
                border: {t["card_border"]};
            }}

            QLabel {{
                color: {t["text_primary"]};
                font-size: 13px;
                border: none;
                background: transparent;
            }}
            QLabel[isTitle="true"] {{
                font-size: 14px;
                font-weight: 600;
                color: {t["text_primary"]};
                padding-left: 2px;
            }}

            QPushButton {{
                background-color: {t["btn_bg"]};
                color: {t["btn_text"]};
                border: 1px solid {t["btn_border"]};
                border-radius: 8px;
                padding: 8px 20px;
                font-size: 13px;
                min-height: 18px;
            }}
            QPushButton:hover {{
                background-color: {t["btn_hover"]};
            }}
            QPushButton:pressed {{
                background-color: {t["btn_pressed"]};
            }}
            QPushButton:disabled {{ background-color: {t["btn_disabled_bg"]}; color: {t["btn_disabled_text"]}; border-color: {t["btn_disabled_border"]};}}

            QPushButton[btnType="primary"] {{
                background-color: {t["btn_primary_bg"]};
                color: {t["btn_primary_text"]};
                border: 1px solid {t["btn_primary_border"]};
            }}
            QPushButton[btnType="primary"]:hover {{
                background-color: {t["btn_primary_hover"]};
            }}
            QPushButton[btnType="danger"] {{
                background-color: {t["btn_danger_bg"]};
                color: {t["btn_danger_text"]};
                border: 1px solid {t["btn_danger_border"]};
            }}
            QPushButton[btnType="danger"]:hover {{
                background-color: {t["btn_danger_hover"]};
            }}
            QPushButton[btnType="warning"] {{
                background-color: {t["btn_warning_bg"]};
                color: {t["btn_warning_text"]};
                border: 1px solid {t["btn_warning_border"]};
            }}
            QPushButton[btnType="warning"]:hover {{
                background-color: {t["btn_warning_hover"]};
            }}

            QLineEdit, QTextEdit, QComboBox, QSpinBox {{
                padding: 9px 12px;
                border: 1px solid {t["border_color"]};
                border-radius: 8px;
                background-color: {t["input_bg"]};
                font-size: 13px;
                color: {t["text_primary"]};
                selection-background-color: {t["selection_bg"]};
                min-height: 18px;
            }}
            QLineEdit:focus, QTextEdit:focus {{
                border: 1px solid {t["input_focus_border"]};
                background-color: {t["input_bg"]};
            }}
            QLineEdit:hover, QTextEdit:hover {{ border-color: {t["input_hover_border"]}; }}
            QComboBox::drop-down {{ border: none; width: 32px; }}
            QComboBox::down-arrow {{
                width: 10px; height: 10px; image: none;
                border-left: 5px solid transparent;
                border-right: 5px solid transparent;
                border-top: 6px solid {t["combo_arrow"]}; margin-right: 8px;
            }}
            QComboBox QAbstractItemView {{
                border: 1px solid {t["border_color"]}; border-radius: 8px;
                background: {t["combo_dropdown_bg"]}; selection-background-color: {t["combo_dropdown_selbg"]};
            }}
            QSpinBox::up-button, QSpinBox::down-button {{
                width: 28px; border: none; background: transparent;
            }}
            QSpinBox::up-arrow, QSpinBox::down-arrow {{
                width: 10px; height: 10px; image: none;
                border-left: 5px solid transparent; border-right: 5px solid transparent;
            }}
            QSpinBox::up-arrow {{ border-bottom: 6px solid {t["combo_arrow"]}; }}
            QSpinBox::down-arrow {{ border-top: 6px solid {t["combo_arrow"]}; }}

            QPushButton#sendBtn {{
                background-color: {t["send_btn_bg"]}; color: {t["send_btn_text"]};
                border: {t["send_btn_border"]}; border-radius: 8px;
                padding: 6px 16px; font-size: 13px; font-weight: bold;
            }}
            QPushButton#sendBtn:hover {{ background-color: {t["send_btn_hover"]}; }}
            QPushButton#sendBtn:pressed {{ background-color: {t["send_btn_pressed"]}; }}

            QScrollBar:vertical {{ width: 6px; background: transparent; margin: 0; }}
            QScrollBar::handle:vertical {{
                background: {t["scrollbar_handle"]}; border-radius: 3px; min-height: 30px;
            }}
            QScrollBar::handle:vertical:hover {{ background: {t["scrollbar_hover"]}; }}
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}
            QScrollBar:horizontal {{ height: 6px; background: transparent; }}
            QScrollBar::handle:horizontal {{
                background: {t["scrollbar_handle"]}; border-radius: 3px; min-width: 30px;
            }}
            QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{ width: 0; }}

            QLabel#videoLabel {{
                background-color: {t["video_bg"]};
                color: {t["video_text"]}; font-size: 14px;
            }}

            QWidget#videoCardContainer {{
                background-color: {t["video_bg"]};
            }}

            QScrollArea {{ border: none; background: {t['dialog_bg']}; }}
            QScrollArea > QWidget#qt_scrollarea_viewport {{
                background-color: {t['dialog_bg']};
            }}
            QToolTip {{
                background-color: {t["tooltip_bg"]}; color: {t["tooltip_text"]}; border: none;
                border-radius: 6px; padding: 5px 10px; font-size: 12px;
            }}

            QPushButton#fabChat, QPushButton#fabSettings {{
                background-color: {t["fab_bg"]};
                color: {t["fab_text"]};
                border: {t["fab_border"]};
                border-radius: 8px;
                font-size: 12px;
                padding: 8px 16px;
            }}
            QPushButton#fabChat:hover, QPushButton#fabSettings:hover {{
                background-color: {t["fab_hover_bg"]};
                border-color: {t["fab_hover_border"]};
            }}

            QWidget#sidePanel {{
                background-color: {t["sidepanel_bg"]};
                border-left: {t["sidepanel_border"]};
            }}

            QDialog#settingsDialog {{
                background-color: {t["dialog_bg"]};
                border-radius: 12px;
            }}

            QWidget#settingsContent {{
                background-color: {t["card_bg"]};
            }}
        """
        self.setStyleSheet(ss)
        # 同时刷新内联样式的控件
        self._refresh_inline_styles()

    def _refresh_inline_styles(self):
        """刷新无法通过全局 QSS 覆盖的内联样式控件（底部栏、侧边栏、设置等）"""
        t = THEMES.get(self._theme_name, THEMES["light"])

        # ---- 状态指示器 ----
        if hasattr(self, 'status_label'):
            self.status_label.set_theme(t)
            # 重新应用当前状态样式
            current = getattr(self.status_label, '_current_status', 'idle')
            self.status_label.set_status(current)

        # ---- 日志面板 ----
        if hasattr(self, 'log_panel'):
            self.log_panel.set_theme(self._theme_name == "dark")

        # ---- 底部菜单栏背景容器 ----
        if hasattr(self, '_bottom_bar_container'):
            self._bottom_bar_container.setStyleSheet(
                f"background-color: {t['bottombar_bg']}; border-radius: 8px;"
            )

        # ---- 底部按钮组 ----
        _btn_style = f"""
            QPushButton {{
                background: {t['btn_bg']}; color:{t['btn_text']};
                border:1px solid {t['btn_border']};
                border-radius:8px; font-size:12px;
                padding: 6px 16px;
            }}
            QPushButton:hover {{ background: {t['btn_hover']}; }}
            QPushButton:checked {{ background: {t['status_speak_bg']}; color:{t['status_speak_text']};
                border-color: rgba(46,125,50,0.2); }}
        """
        if hasattr(self, 'log_toggle_btn'):
            self.log_toggle_btn.setStyleSheet(_btn_style)

        if hasattr(self, 'manual_listen_btn'):
            self.manual_listen_btn.setStyleSheet(f"""
                QPushButton {{
                    background: {t['btn_primary_bg']}; color:{t['btn_primary_text']};
                    border:1px solid {t['btn_primary_border']};
                    border-radius:8px; font-size:12px; padding: 6px 16px;
                }}
                QPushButton:hover {{ background: {t['btn_primary_hover']}; }}
            """)
        if hasattr(self, 'stop_btn'):
            self.stop_btn.setStyleSheet(f"""
                QPushButton {{
                    background: {t['btn_danger_bg']}; color:{t['btn_danger_text']};
                    border:1px solid {t['btn_danger_border']};
                    border-radius:8px; font-size:12px; padding: 6px 16px;
                }}
                QPushButton:hover {{ background: {t['btn_danger_hover']}; }}
            """)

        # ---- 状态标签 ----
        if hasattr(self, 'model_status_lbl'):
            self.model_status_lbl.setStyleSheet(f"color: {t['text_muted']}; font-size:11px;")
        if hasattr(self, 'model_lbl'):
            self.model_lbl.setStyleSheet(f"color: {t['text_secondary']}; font-size:12px;")

        # ---- 侧边栏头部 ----
        if hasattr(self, 'side_panel'):
            header_style = f"""
                QFrame {{
                    background-color: {t['header_bg']};
                    border-bottom: {t['header_border']};
                }}
                QLabel {{ color: {t['header_title']}; font-size: 14px; font-weight: 600; padding: 4px; }}
                QPushButton {{ background: rgba(0,0,0,0.04); border: none;
                              border-radius: 6px; padding: 4px 10px; font-size: 13px;
                              color: {t['text_secondary']};}}
                QPushButton:hover {{ background: rgba(0,0,0,0.08); }}
            """
            for child in self.side_panel.findChildren(QFrame):
                if child != self.side_panel:
                    child.setStyleSheet(header_style)
                    break

            # 关闭按钮
            for btn in self.side_panel.findChildren(QPushButton):
                if btn.text().strip() in ('x', '\u2715'):
                    btn.setStyleSheet(f"""
                        QPushButton {{ background: transparent; color: {t['close_btn_text_def']};
                                       border: none; font-size: 16px; font-weight: bold;
                                       border-radius: 6px; padding: 4px 8px; min-width: 30px;}}
                        QPushButton:hover {{ background: {t['close_btn_hover_bg']}; color: {t['close_btn_hover_text']}; }}
                    """)
                    break

        # ---- 聊天滚动区 ----
        if hasattr(self, 'chat_scroll'):
            self.chat_scroll.setStyleSheet(f"""
                QScrollArea#chatScroll {{
                    border: 1px solid {t['border_light']}; border-radius: 10px;
                    background: {t['chat_scroll_bg']};
                }}
                QScrollArea#chatScroll > QWidget#qt_scrollarea_viewport {{
                    background-color: {t['chat_scroll_bg']};
                }}
                QScrollBar:vertical {{ width: 5px; background: transparent; }}
                QScrollBar::handle:vertical {{
                    background: {t['scrollbar_handle']}; border-radius: 2px; min-height: 20px;
                }}
                QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}
            """)

        # ---- 聊天输入框 ----
        if hasattr(self, 'chat_input_box'):
            self.chat_input_box.setStyleSheet(f"""
                QFrame#chatInputBox {{
                    background-color: {t['chat_input_bg']}; border-radius: 8px;
                    border: 1px solid {t['chat_input_border']};
                }}
            """)

        # ---- 音色标签 ----
        if hasattr(self, 'current_voice_label'):
            self.current_voice_label.setStyleSheet(f"""
                QLabel {{
                    color: {t['voice_label_text']};
                    font-size: 13px;
                    font-weight: {t['voice_label_fw']};
                    padding: 4px 10px;
                    background: {t['voice_label_bg']};
                    border-radius: 6px;
                }}
            """)

        # ---- 视频路径标签 ----
        if hasattr(self, 'video_path_label'):
            self.video_path_label.setStyleSheet(f"color:{t['text_muted']}; font-size:12px;")

        # ---- 分隔线 ----
        if hasattr(self, '_sep_widget'):
            self._sep_widget.setStyleSheet(f"color: {t['separator']};")

        # ---- 语速/音调值标签 ----
        _val_lbl_style = f"color: {t['voice_label_text']}; font-weight:600; font-size:13px;"
        if hasattr(self, 'speed_value_lbl'):
            self.speed_value_lbl.setStyleSheet(_val_lbl_style)
        if hasattr(self, 'pitch_value_lbl'):
            self.pitch_value_lbl.setStyleSheet(_val_lbl_style)

        # ---- 试听按钮 ----
        if hasattr(self, 'preview_btn'):
            self.preview_btn.setStyleSheet(f"""
                QPushButton#ttsPreviewBtn {{
                    background-color: {t['btn_primary_bg']}; color: {t['btn_primary_text']};
                    border: 1px solid {t['btn_primary_border']}; border-radius: 6px;
                    font-size: 12px; font-weight: 600;
                }}
                QPushButton#ttsPreviewBtn:hover {{ background-color: {t['btn_primary_hover']}; }}
                QPushButton#ttsPreviewBtn:disabled {{ background-color: {t['btn_disabled_bg']}; color: {t['btn_disabled_text']}; }}
            """)

        # ---- 设置对话框（如果已打开，同步刷新）----
        if hasattr(self, 'settings_dialog') and self.settings_dialog is not None:
            self.settings_dialog.setStyleSheet(
                f"QDialog#settingsDialog {{ background-color: {t['dialog_bg']}; }}"
            )
            # 刷新内容区背景
            if hasattr(self, '_settings_content') and self._settings_content:
                self._settings_content.setStyleSheet(f"background-color: {t['card_bg']};")
        self.setWindowTitle("智能语音助手")
        self.setGeometry(100, 100, 1280, 850)

    def init_ui(self):
        font = QFont("Microsoft YaHei", 9)
        self.setFont(font)

        # ===== 全局样式表（支持 light / dark 主题切换） =====
        self._apply_global_stylesheet()

        # ---- 中央部件（全屏视频背景）----
        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QVBoxLayout(central)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # 主区域：视频 + 底部控制条
        self._build_main_area(main_layout)

        # 悬浮按钮层（叠加在主区域右上角）
        self._build_fab_buttons(central)

        # 侧边栏（文字对话面板）
        self._build_side_panel(central)

        # 设置弹窗
        self.settings_dialog = None

        # 预先构建设置控件，确保 load_settings 时所有属性（wake_word_input 等）已存在
        # 保存引用防止垃圾回收导致控件被销毁
        self._settings_content = self._build_settings_content_widget()
        self._settings_content.setParent(self)
        self._settings_content.hide()

    def _build_main_area(self, parent_layout):
        """构建主区域：波形 + 视频 + 日志面板 + 底部状态栏"""
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(4)

        # ---- [0] AI 语音波形组件（视频正上方，等宽）----
        self.waveform = VoiceWaveform()
        self.waveform.hide()  # 默认隐藏
        layout.addWidget(self.waveform)

        # ---- [1] 视频AI形象展示区（填满整个剩余空间）----
        video_card = QWidget()
        video_card.setObjectName("videoCardContainer")

        self.video_label = QLabel()
        self.video_label.setObjectName("videoLabel")
        self.video_label.setAlignment(Qt.AlignCenter)
        self.video_label.setText("\n\n\n       AI 助手形象\n\n     当AI回答时将在此播放视频\n\n\n")
        # 保存原始 pixmap，供 resize 时重绘（避免反复缩放失真）
        self._original_pixmap = None

        vl = QVBoxLayout(video_card)
        vl.setContentsMargins(0, 0, 0, 0)
        vl.addWidget(self.video_label, 1)
        layout.addWidget(video_card, 1)  # 视频占主要空间

        # ---- [3] 可折叠日志面板（默认隐藏，由底部"日志"按钮控制） ----
        self.log_panel = LogPanel()
        self.log_panel.hide()  # 默认完全隐藏
        layout.addWidget(self.log_panel)

        # ---- [4] 底部状态与控制栏（带淡色背景） ----
        self._bottom_bar_container = QWidget()
        self._bottom_bar_container.setObjectName("bottomBarContainer")
        bottom_bar = QHBoxLayout(self._bottom_bar_container)
        bottom_bar.setSpacing(12)
        bottom_bar.setContentsMargins(16, 8, 16, 8)

        # 左侧区域：状态 + 搜索状态
        left_area = QHBoxLayout()
        left_area.setSpacing(10)

        self.status_label = StatusIndicator()
        left_area.addWidget(self.status_label)

        # 联网搜索状态小标签
        self.search_status_lbl = QLabel("")
        left_area.addWidget(self.search_status_lbl)

        bottom_bar.addLayout(left_area)
        bottom_bar.addStretch()

        # 右侧：操作按钮组（统一尺寸）
        btn_group = QHBoxLayout()
        btn_group.setSpacing(8)

        self.log_toggle_btn = QPushButton("日志")
        self.log_toggle_btn.setFixedSize(80, 36)
        self.log_toggle_btn.setCursor(Qt.PointingHandCursor)
        self.log_toggle_btn.setCheckable(True)
        self.log_toggle_btn.setChecked(False)
        self.log_toggle_btn.clicked.connect(lambda checked: self._on_log_toggle(checked))
        btn_group.addWidget(self.log_toggle_btn)

        self.manual_listen_btn = QPushButton("唤醒")
        self.manual_listen_btn.setFixedSize(80, 36)
        self.manual_listen_btn.clicked.connect(self.on_manual_listen)
        btn_group.addWidget(self.manual_listen_btn)

        self.stop_btn = QPushButton("停止")
        self.stop_btn.setFixedSize(80, 36)
        self.stop_btn.clicked.connect(self.on_stop)
        btn_group.addWidget(self.stop_btn)

        bottom_bar.addLayout(btn_group)
        layout.addWidget(self._bottom_bar_container)

        parent_layout.addWidget(container, 1)

    def _build_fab_buttons(self, parent):
        """构建右上角悬浮小按钮"""
        fab_container = QWidget(parent)
        fab_container.setObjectName("fabContainer")
        fab_container.setFixedSize(176, 40)
        fab_container.move(16, 14)

        fab_layout = QHBoxLayout(fab_container)
        fab_layout.setSpacing(6)
        fab_layout.setContentsMargins(0, 0, 0, 0)

        # 系统设置排在第一位（左）
        self.fab_settings_btn = QPushButton("系统设置")
        self.fab_settings_btn.setObjectName("fabSettings")
        self.fab_settings_btn.setCursor(Qt.PointingHandCursor)
        self.fab_settings_btn.clicked.connect(self._show_settings_dialog)
        self.fab_settings_btn.setFixedWidth(85)
        self.fab_settings_btn.setSizePolicy(self.fab_settings_btn.sizePolicy().horizontalPolicy(), self.fab_settings_btn.sizePolicy().verticalPolicy())
        fab_layout.addWidget(self.fab_settings_btn)

        # 文字对话排在第二位（右）
        self.fab_chat_btn = QPushButton("文字对话")
        self.fab_chat_btn.setObjectName("fabChat")
        self.fab_chat_btn.setCursor(Qt.PointingHandCursor)
        self.fab_chat_btn.clicked.connect(self._toggle_side_panel)
        self.fab_chat_btn.setFixedWidth(85)
        fab_layout.addWidget(self.fab_chat_btn)

        # 占位：隐藏聊天按钮后，设置按钮不拉伸
        fab_layout.addStretch()

        # 记录以便窗口resize时跟随
        self._fab_container = fab_container

    def _build_side_panel(self, parent):
        """构建右侧滑出式文字对话面板"""
        self.side_panel = QWidget(parent)
        self.side_panel.setObjectName("sidePanel")
        self.side_panel.setFixedWidth(420)
        self.side_panel.hide()

        panel_layout = QVBoxLayout(self.side_panel)
        panel_layout.setContentsMargins(0, 0, 0, 0)
        panel_layout.setSpacing(0)

        # 标题栏
        header = QFrame()
        header.setStyleSheet("""
            QFrame {
                background-color: #FFFFFF;
                border-bottom: 1px solid rgba(0, 0, 0, 0.06);
            }
            QLabel { color: #333333; font-size: 14px; font-weight: 600; padding: 4px; }
            QPushButton { background: rgba(0,0,0,0.04); border: none;
                          border-radius: 6px; padding: 4px 10px; font-size: 13px;
                          color: #666666;}
            QPushButton:hover { background: rgba(0,0,0,0.08); }
        """)
        hdr_layout = QHBoxLayout(header)
        hdr_layout.setContentsMargins(14, 12, 8, 12)

        title_lbl = QLabel("文字对话")
        title_lbl.setStyleSheet("color:#333333; font-size:14px; font-weight:600;")
        hdr_layout.addWidget(title_lbl)

        hdr_layout.addStretch()

        close_btn = QPushButton(" x ")
        close_btn.setStyleSheet("""
            QPushButton { background: transparent; color: #999999;
                           border: none; font-size: 16px; font-weight: bold;
                           border-radius: 6px; padding: 4px 8px; min-width: 30px;}
            QPushButton:hover { background: rgba(200,50,50,0.08); color: #C0392B; }
        """)
        close_btn.setCursor(Qt.PointingHandCursor)
        close_btn.clicked.connect(lambda: self._toggle_side_panel(hide_only=True))
        hdr_layout.addWidget(close_btn)

        panel_layout.addWidget(header)

        # 对话内容区（复用原有聊天构建逻辑）
        body = QWidget()
        body_layout = QVBoxLayout(body)
        body_layout.setContentsMargins(8, 8, 8, 8)
        body_layout.setSpacing(8)

        # 工具栏
        toolbar = QHBoxLayout()
        toolbar.addWidget(QLabel("模型："))
        self.chat_model_combo = QComboBox()
        self.chat_model_combo.addItems(["DeepSeek", "豆包"])
        self.chat_model_combo.setFixedWidth(130)
        self.chat_model_combo.currentTextChanged.connect(self.on_chat_model_changed)
        self.chat_model_combo._wheel_enabled = False
        self.chat_model_combo.installEventFilter(self)
        toolbar.addWidget(self.chat_model_combo)

        self.api_status_label = QLabel("")
        self.api_status_label.setStyleSheet("font-size:11px;")
        toolbar.addWidget(self.api_status_label)
        toolbar.addStretch()

        clear_btn = QPushButton("  清空对话  ")
        clear_btn.setProperty("btnType", "warning")
        clear_btn.setFixedWidth(90)
        clear_btn.clicked.connect(self.on_clear_history)
        toolbar.addWidget(clear_btn)

        # 语音回复开关（默认开启）
        self.chat_voice_btn = QPushButton("  🔊 语音  ")
        self.chat_voice_btn.setCheckable(True)
        self.chat_voice_btn.setChecked(True)  # 默认播放语音
        self.chat_voice_btn.setFixedWidth(80)
        self.chat_voice_btn.setCursor(Qt.PointingHandCursor)
        self.chat_voice_btn.setToolTip("开启后，AI文字回复会同时播放语音")
        self.chat_voice_btn.clicked.connect(self._on_chat_voice_toggle)
        toolbar.addWidget(self.chat_voice_btn)

        body_layout.addLayout(toolbar)

        # 聊天滚动区
        self.chat_scroll = QScrollArea()
        scroll = self.chat_scroll
        scroll.setObjectName("chatScroll")
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setStyleSheet("""
            QScrollArea#chatScroll {
                border: 1px solid rgba(0,0,0,0.06); border-radius: 10px;
                background: #FAFBFC;
            }
            QScrollBar:vertical { width: 5px; background: transparent; }
            QScrollBar::handle:vertical {
                background: #D4CFE0; border-radius: 2px; min-height: 20px;
            }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
        """)

        self.chat_container = QWidget()
        self.chat_layout = QVBoxLayout(self.chat_container)
        self.chat_layout.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        self.chat_layout.setSpacing(4)
        self.chat_layout.setContentsMargins(10, 6, 10, 6)

        scroll.setWidget(self.chat_container)
        body_layout.addWidget(scroll, 1)

        # 输入区
        self.chat_input_box = QFrame()
        self.chat_input_box.setObjectName("chatInputBox")
        input_layout = QHBoxLayout(self.chat_input_box)
        input_layout.setContentsMargins(10, 8, 10, 8)
        input_layout.setSpacing(8)

        self.text_input = QTextEdit()
        self.text_input.setObjectName("textInput")
        self.text_input.setPlaceholderText("输入消息...")
        self.text_input.setMaximumHeight(70)
        self.text_input.installEventFilter(self)  # 回车发送消息
        input_layout.addWidget(self.text_input, 1)

        send_btn = QPushButton("发送")
        send_btn.setObjectName("sendBtn")
        send_btn.setFixedSize(60, 36)
        send_btn.setCursor(Qt.PointingHandCursor)
        send_btn.clicked.connect(self.on_send_text)
        input_layout.addWidget(send_btn)

        body_layout.addWidget(self.chat_input_box)

        panel_layout.addWidget(body, 1)

        # 面板位置：紧贴右侧
        geo = parent.geometry()
        self.side_panel.move(geo.width(), 0)
        self.side_panel.raise_()

        # 动画属性
        self._panel_visible = False
        self._panel_anim = None

    def on_search_status(self, status, info):
        """联网搜索状态变化回调"""
        if not hasattr(self, 'search_status_lbl'):
            return
        t = THEMES.get(self._theme_name, THEMES["light"])
        if status == "searching":
            self.search_status_lbl.setText("  正在联网搜索...")
            self.search_status_lbl.setStyleSheet(
                f"color: {t['search_doing_color']}; font-size:11px; font-weight:normal;"
            )
            if hasattr(self, 'log_panel'):
                self.log_panel.append_log("system", f"正在联网搜索: {info}")
        else:
            has_result = info and info != "无结果"
            if has_result:
                self.search_status_lbl.setText("  搜索完成")
                self.search_status_lbl.setStyleSheet(
                    f"color: {t['search_done_color']}; font-size:11px; font-weight:normal;"
                )
                if hasattr(self, 'log_panel'):
                    self.log_panel.append_log("system", "联网搜索已完成")
            else:
                self.search_status_lbl.setText("")
                if hasattr(self, 'log_panel') and info == "无结果":
                    self.log_panel.append_log("voice", "联网搜索未找到结果，使用普通模式")

    # ==================== 主题切换 ====================

    @staticmethod
    def _detect_system_theme():
        """检测操作系统当前是深色还是浅色模式"""
        try:
            if platform.system() == "Windows":
                import winreg
                key = winreg.OpenKey(
                    winreg.HKEY_CURRENT_USER,
                    r"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize"
                )
                value, _ = winreg.QueryValueEx(key, "AppsUseLightTheme")
                return "light" if value == 1 else "dark"
            elif platform.system() == "Darwin":  # macOS
                # macOS: NSAppearanceNameAqua = light
                from subprocess import check_output
                result = check_output(["defaults", "read", "-g", "AppleInterfaceStyle"],
                                      stderr=subprocess.DEVNULL)
                return "dark" if b"Dark" in result else "light"
            else:
                # Linux: 检查 GTK_THEME 或 DE 设置
                import os
                gtk_theme = os.environ.get("GTK_THEME", "").lower()
                if "dark" in gtk_theme:
                    return "dark"
                return "light"
        except Exception:
            return "light"

    def _resolve_theme(self, setting_value):
        """将用户设置值解析为实际主题名 ('light' / 'dark')"""
        if setting_value == "system":
            return self._detect_system_theme()
        return setting_value

    def switch_theme(self, theme_name):
        """切换到指定主题并刷新全部样式"""
        resolved = self._resolve_theme(theme_name)
        if resolved == self._theme_name:
            return
        self._theme_name = resolved
        self._apply_global_stylesheet()

    def _on_theme_preview_changed(self, index):
        """设置中主题下拉框切换时实时预览（不立即保存）"""
        mapping = {0: "system", 1: "light", 2: "dark"}
        target = mapping.get(index, "system")
        resolved = self._resolve_theme(target)
        if resolved != self._theme_name:
            self._theme_name = resolved
            self._apply_global_stylesheet()

    def eventFilter(self, obj, event):
        """事件过滤器：下拉框滚轮控制 + 文本框回车发送"""
        # 文本输入框：回车发送 / Ctrl+回车换行
        if obj is getattr(self, 'text_input', None) and event.type() == event.KeyPress:
            self._text_key_press(event)
            return True
        if event.type() == event.Wheel:
            if hasattr(obj, '_wheel_enabled') and not obj._wheel_enabled:
                # 只有点击展开了下拉列表才允许滚轮选择
                try:
                    popup_visible = obj.view() and obj.view().isVisible()
                except Exception:
                    popup_visible = False
                if not popup_visible:
                    return True  # 拦截滚轮事件
        return super().eventFilter(obj, event)

    def resizeEvent(self, event):
        """窗口缩放时调整悬浮按钮、侧边栏位置，并重新缩放视频图片"""
        super().resizeEvent(event)
        if hasattr(self, '_fab_container') and self._fab_container:
            w = self.width()
            self._fab_container.move(20, 20)
        if hasattr(self, 'side_panel') and self.side_panel.isVisible():
            sp_w = self.side_panel.width()
            self.side_panel.move(self.width() - sp_w, 0)
        # 视频区静态图片（首帧/占位图）随窗口自适应重绘
        if hasattr(self, '_original_pixmap') and self._original_pixmap and not self._original_pixmap.isNull():
            scaled = self._original_pixmap.scaled(
                self.video_label.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation
            )
            self.video_label.setPixmap(scaled)

    # ==================== 侧边栏显示/隐藏 ====================

    def _toggle_side_panel(self, hide_only=False):
        """切换侧边栏显示/隐藏（带滑动动画）"""
        if hide_only:
            self._slide_panel(False)
            return

        if self._panel_visible:
            self._slide_panel(False)
        else:
            self._slide_panel(True)

    def _slide_panel(self, show):
        """执行侧边栏滑动动画"""
        if self._panel_anim is not None and self._panel_anim.state() == QAbstractAnimation.Running:
            return

        sp_w = self.side_panel.width()
        sp_h = max(self.height(), 600)
        target_x = self.width() - sp_w if show else self.width()

        # 先确保尺寸正确
        self.side_panel.setGeometry(self.width(), 0, sp_w, sp_h)

        # 动画：仅移动 X 坐标
        self._panel_anim = QPropertyAnimation(self.side_panel, b"pos")
        self._panel_anim.setDuration(280)
        self._panel_anim.setEasingCurve(QEasingCurve.OutCubic)
        self._panel_anim.setStartValue(self.side_panel.pos())
        self._panel_anim.setEndValue(QPoint(target_x, 0))

        def _on_finished():
            self._panel_visible = show
            if not show:
                self.side_panel.hide()

        self._panel_anim.finished.connect(_on_finished)

        self.side_panel.show()
        self.side_panel.raise_()
        self._panel_anim.start()

    # ==================== 设置弹窗 ====================

    def _show_settings_dialog(self):
        """显示设置弹窗（模态对话框）"""
        t = THEMES.get(self._theme_name, THEMES["light"])

        dlg = QDialog(self)
        dlg.setObjectName("settingsDialog")
        dlg.setWindowTitle("系统设置")
        # 初始尺寸，允许用户手动拉伸
        dlg.setMinimumSize(600, 700)
        dlg.resize(680, 750)
        # 去掉 Windows 默认的"?"帮助按钮（点了没反应）
        dlg.setWindowFlags(dlg.windowFlags() & ~Qt.WindowContextHelpButtonHint)
        dlg.setStyleSheet(dlg.styleSheet() + f"""
            QDialog#settingsDialog {{
                background-color: {t['dialog_bg']};
            }}
        """)

        layout = QVBoxLayout(dlg)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(14)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setStyleSheet(f"QScrollArea {{ border:none; background: {t['dialog_bg']}; }}")

        # 每次重新构建设置内容，避免复用已销毁控件导致闪退
        content = self._build_settings_content_widget()
        scroll.setWidget(content)
        layout.addWidget(scroll, 1)

        save_btn = QPushButton("保存设置")
        save_btn.setFixedHeight(40)
        save_btn.setFont(QFont("Microsoft YaHei", 11))
        save_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {t['save_btn_bg']}; color: #FFFFFF;
                border: none; border-radius: 8px;
                font-weight: 600;
            }}
            QPushButton:hover {{ background-color: {t['save_btn_hover']}; }}
            QPushButton:pressed {{ background-color: {t['save_btn_pressed']}; }}
        """)
        save_btn.clicked.connect(lambda: self._on_save_from_dialog(dlg))
        layout.addWidget(save_btn)

        if hasattr(self.controller, 'settings'):
            self._load_settings_to_widgets(self.controller.settings)

        self.settings_dialog = dlg
        dlg.exec_()
        self.settings_dialog = None

    def _build_settings_content_widget(self):
        """构建设置内容 widget"""
        content = QWidget()
        content.setObjectName("settingsContent")
        layout = QVBoxLayout(content)
        layout.setSpacing(14)
        layout.setContentsMargins(6, 10, 6, 10)
        layout.setAlignment(Qt.AlignTop)

        # 唤醒设置
        layout.addWidget(self._build_section("唤醒设置", [
            ("唤醒词：", "wake_word_input", "例如：小智"),
            ("唤醒回复：", "wake_response_input", "例如：在的，请说"),
        ]))

        # 语音设置（音色管理）
        voice_card = CardPanel()
        voice_inner = QVBoxLayout(voice_card)
        voice_inner.setContentsMargins(16, 14, 16, 14)
        voice_inner.setSpacing(12)

        vt = QLabel("语音音色设置")
        vt.setProperty("isTitle", True)
        voice_inner.addWidget(vt)

        # ---- 行0: TTS引擎选择 ----
        row_engine = QHBoxLayout()
        row_engine.addWidget(QLabel("TTS引擎："))
        self.tts_engine_combo = QComboBox()
        self.tts_engine_combo.addItems(["百度在线TTS（自然音色）", "本地SAPI5（系统默认）"])
        self.tts_engine_combo.currentIndexChanged.connect(self._on_tts_engine_changed)
        self.tts_engine_combo._wheel_enabled = False
        self.tts_engine_combo.installEventFilter(self)
        row_engine.addWidget(self.tts_engine_combo, 1)
        row_engine.addStretch()
        voice_inner.addLayout(row_engine)

        # ---- 行1: 当前音色显示 + 下拉选择 + 试听按钮 ----
        row_voice = QHBoxLayout()
        row_voice.setSpacing(10)

        # 当前音色标签
        self.current_voice_label = QLabel("当前：度晓晓(AI助手女声)")
        row_voice.addWidget(self.current_voice_label)

        row_voice.addSpacing(8)

        # 音色下拉框
        row_voice.addWidget(QLabel("选择音色："))
        self.baidu_voice_combo = QComboBox()
        self.baidu_voice_combo.setFocusPolicy(Qt.StrongFocus)
        # 默认禁用滚轮，点击聚焦后才允许
        self.baidu_voice_combo._wheel_enabled = False
        # 填充免费可用音色
        for vid, vname, desc, is_rec in Config.BAIDU_VOICES_FREE:
            display = f"★ {vname}" if is_rec else f"  {vname}"
            self.baidu_voice_combo.addItem(display, userData=vid)
        # 添加分隔 + 付费音色
        if Config.BAIDU_VOICES_PREMIUM:
            self.baidu_voice_combo.insertSeparator(self.baidu_voice_combo.count())
            for vid, vname, desc in Config.BAIDU_VOICES_PREMIUM:
                self.baidu_voice_combo.addItem(f"$ 付费: {vname}", userData=vid)
        self.baidu_voice_combo.currentIndexChanged.connect(self._on_baidu_voice_changed)
        self.baidu_voice_combo.installEventFilter(self)  # 滚轮锁定
        row_voice.addWidget(self.baidu_voice_combo, 1)

        # 试听按钮
        self.preview_btn = QPushButton(" 试听 ")
        self.preview_btn.setObjectName("ttsPreviewBtn")
        self.preview_btn.setFixedSize(70, 34)
        self.preview_btn.setCursor(Qt.PointingHandCursor)
        t_preview = THEMES.get(self._theme_name, THEMES["light"])
        self.preview_btn.setStyleSheet(f"""
            QPushButton#ttsPreviewBtn {{
                background-color: {t_preview['btn_primary_bg']}; color: {t_preview['btn_primary_text']};
                border: 1px solid {t_preview['btn_primary_border']}; border-radius: 6px;
                font-size: 12px; font-weight: 600;
            }}
            QPushButton#ttsPreviewBtn:hover {{ background-color: {t_preview['btn_primary_hover']}; }}
            QPushButton#ttsPreviewBtn:disabled {{ background-color: {t_preview['btn_disabled_bg']}; color: {t_preview['btn_disabled_text']}; }}
        """)
        self.preview_btn.clicked.connect(self._on_preview_voice)
        row_voice.addWidget(self.preview_btn)

        voice_inner.addLayout(row_voice)

        # ---- 行2: 语速 + 音调滑块 ----
        row_params = QHBoxLayout()
        row_params.setSpacing(20)

        # 语速滑块
        speed_col = QVBoxLayout()
        speed_col.setSpacing(4)
        spd_hdr = QHBoxLayout()
        spd_hdr.addWidget(QLabel("语速："))
        self.speed_value_lbl = QLabel("5")
        self.speed_value_lbl.setFixedWidth(24)
        self.speed_value_lbl.setAlignment(Qt.AlignCenter)
        spd_hdr.addWidget(self.speed_value_lbl)
        spd_hdr.addWidget(QLabel("(快← →慢)"))
        spd_hdr.addStretch()
        speed_col.addLayout(spd_hdr)
        self.speed_slider = QSlider(Qt.Horizontal)
        self.speed_slider.setRange(0, 15)
        self.speed_slider.setValue(5)
        self.speed_slider.valueChanged.connect(lambda v: self.speed_value_lbl.setText(str(v)))
        speed_col.addWidget(self.speed_slider)
        row_params.addLayout(speed_col)

        # 分隔线
        sep = QFrame()
        sep.setFrameShape(QFrame.VLine)
        self._sep_widget = sep
        sep.setFixedHeight(40)
        row_params.addWidget(sep)

        # 音调滑块
        pitch_col = QVBoxLayout()
        pitch_col.setSpacing(4)
        pch_hdr = QHBoxLayout()
        pch_hdr.addWidget(QLabel("音调："))
        self.pitch_value_lbl = QLabel("5")
        self.pitch_value_lbl.setFixedWidth(24)
        self.pitch_value_lbl.setAlignment(Qt.AlignCenter)
        pch_hdr.addWidget(self.pitch_value_lbl)
        pch_hdr.addWidget(QLabel("(低← →高)"))
        pch_hdr.addStretch()
        pitch_col.addLayout(pch_hdr)
        self.pitch_slider = QSlider(Qt.Horizontal)
        self.pitch_slider.setRange(0, 15)
        self.pitch_slider.setValue(5)
        self.pitch_slider.valueChanged.connect(lambda v: self.pitch_value_lbl.setText(str(v)))
        pitch_col.addWidget(self.pitch_slider)
        row_params.addLayout(pitch_col)

        row_params.addStretch()
        voice_inner.addLayout(row_params)

        layout.addWidget(voice_card)

        # AI模型设置（model_combo 必须在 _build_section 之前创建）
        self.model_combo = QComboBox()
        self.model_combo.addItems(["DeepSeek", "豆包"])
        self.model_combo.currentTextChanged.connect(self.on_model_changed)
        self.model_combo._wheel_enabled = False
        self.model_combo.installEventFilter(self)

        layout.addWidget(self._build_section("AI 模型设置", [
            ("选择模型：", None, None, True),
            ("DeepSeek API Key：", "deepseek_key_input", "输入您的DeepSeek API密钥", False, True),
            ("豆包 API Key：", "doubao_key_input", "输入您的豆包API密钥", False, True),
        ]))

        # 语音识别引擎（STT）
        stt_card = CardPanel()
        stt_lay = QVBoxLayout(stt_card)
        stt_lay.setContentsMargins(14, 12, 14, 12)
        stt_lay.setSpacing(10)
        stt_title = QLabel("语音识别引擎（STT）")
        stt_title.setProperty("isTitle", True)
        stt_lay.addWidget(stt_title)

        stt_row = QHBoxLayout()
        stt_row.addWidget(QLabel("识别引擎："))
        self.stt_engine_combo = QComboBox()
        self.stt_engine_combo.addItems(["百度智能云（推荐，中文准）", "Google Speech（需网络，免费）"])
        self.stt_engine_combo.currentIndexChanged.connect(self._on_stt_engine_changed)
        self.stt_engine_combo._wheel_enabled = False
        self.stt_engine_combo.installEventFilter(self)
        stt_row.addWidget(self.stt_engine_combo, 1)
        stt_lay.addLayout(stt_row)

        # 百度凭据区域（根据引擎开关显隐）
        self.baidu_stt_group = QWidget()
        baidu_stt_inner = QVBoxLayout(self.baidu_stt_group)
        baidu_stt_inner.setContentsMargins(0, 4, 0, 0)
        baidu_stt_inner.setSpacing(8)

        baidu_id_row = QHBoxLayout()
        baidu_id_row.addWidget(QLabel("APP ID："))
        self.baidu_app_id_input = QLineEdit()
        self.baidu_app_id_input.setPlaceholderText("从百度智能云控制台获取")
        baidu_id_row.addWidget(self.baidu_app_id_input, 1)
        baidu_stt_inner.addLayout(baidu_id_row)

        baidu_key_row = QHBoxLayout()
        baidu_key_row.addWidget(QLabel("API Key："))
        self.baidu_api_key_input = QLineEdit()
        self.baidu_api_key_input.setPlaceholderText("从百度智能云控制台获取")
        baidu_key_row.addWidget(self.baidu_api_key_input, 1)
        baidu_stt_inner.addLayout(baidu_key_row)

        baidu_secret_row = QHBoxLayout()
        baidu_secret_row.addWidget(QLabel("Secret Key："))
        self.baidu_secret_key_input = QLineEdit()
        self.baidu_secret_key_input.setPlaceholderText("从百度智能云控制台获取")
        baidu_secret_row.addWidget(self.baidu_secret_key_input, 1)
        baidu_stt_inner.addLayout(baidu_secret_row)

        stt_lay.addWidget(self.baidu_stt_group)

        layout.addWidget(stt_card)

        # 视频设置
        vid_card = CardPanel()
        vid_lay = QVBoxLayout(vid_card)
        vid_lay.setContentsMargins(14, 12, 14, 12)
        vid_lay.setSpacing(10)
        vt2 = QLabel("视频设置")
        vt2.setProperty("isTitle", True)
        vid_lay.addWidget(vt2)
        vid_r = QHBoxLayout()
        self.video_path_label = QLabel("未选择视频")
        vid_r.addWidget(self.video_path_label, 1)
        vb = QPushButton(" 选择视频 ")
        vb.setMaximumWidth(110)
        vb.clicked.connect(self.on_select_video)
        vid_r.addWidget(vb)
        vid_lay.addLayout(vid_r)
        layout.addWidget(vid_card)

        # 其他设置
        other_card = CardPanel()
        other_inner = QVBoxLayout(other_card)
        other_inner.setContentsMargins(14, 12, 14, 12)
        other_inner.setSpacing(10)
        ot = QLabel("其他设置")
        ot.setProperty("isTitle", True)
        other_inner.addWidget(ot)

        # 联网搜索开关
        row_search = QHBoxLayout()
        row_search.addWidget(QLabel("联网搜索："))
        self.web_search_combo = QComboBox()
        self.web_search_combo.addItems(["开启（自动查天气/新闻等）", "关闭（纯离线模式）"])
        self.web_search_combo.setFixedWidth(220)
        self.web_search_combo._wheel_enabled = False
        self.web_search_combo.installEventFilter(self)
        row_search.addWidget(self.web_search_combo, 1)
        row_search.addStretch()
        other_inner.addLayout(row_search)

        # 待机超时
        row2 = QHBoxLayout()
        row2.addWidget(QLabel("待机超时（秒）："))
        self.timeout_spin = QSpinBox()
        self.timeout_spin.setRange(3, 60)
        self.timeout_spin.setValue(5)
        row2.addWidget(self.timeout_spin)
        row2.addStretch()
        other_inner.addLayout(row2)

        # 外观主题
        row_theme = QHBoxLayout()
        row_theme.addWidget(QLabel("外观主题："))
        self.theme_combo = QComboBox()
        self.theme_combo.addItems(["跟随系统", "浅色模式", "深色模式"])
        self.theme_combo.setFixedWidth(160)
        self.theme_combo._wheel_enabled = False
        self.theme_combo.installEventFilter(self)
        self.theme_combo.currentIndexChanged.connect(self._on_theme_preview_changed)
        row_theme.addWidget(self.theme_combo, 1)
        row_theme.addStretch()
        other_inner.addLayout(row_theme)

        # 文字对话面板显示/隐藏开关
        row_chat_panel = QHBoxLayout()
        row_chat_panel.addWidget(QLabel("文字对话面板："))
        self.chat_panel_visible_combo = QComboBox()
        self.chat_panel_visible_combo.addItems(["显示", "隐藏"])
        self.chat_panel_visible_combo.setFixedWidth(120)
        self.chat_panel_visible_combo._wheel_enabled = False
        self.chat_panel_visible_combo.installEventFilter(self)
        self.chat_panel_visible_combo.currentIndexChanged.connect(self._on_chat_panel_visibility_changed)
        row_chat_panel.addWidget(self.chat_panel_visible_combo, 1)
        row_chat_panel.addStretch()
        other_inner.addLayout(row_chat_panel)

        layout.addWidget(other_card)

        layout.addStretch()
        return content

    def _on_save_from_dialog(self, dialog):
        """从设置弹窗保存"""
        self.on_save_settings()
        dialog.accept()

    def _build_section(self, title_text, fields):
        """构建一个设置分组卡片"""
        card = CardPanel()
        lay = QVBoxLayout(card)
        lay.setContentsMargins(14, 12, 14, 12)
        lay.setSpacing(10)

        title = QLabel(title_text)
        title.setProperty("isTitle", True)
        lay.addWidget(title)

        for field in fields:
            is_combo = len(field) >= 3 and field[3] if len(field) > 3 else False
            is_password = len(field) >= 5 and field[4] if len(field) > 4 else False

            row = QHBoxLayout()
            row.addWidget(QLabel(field[0]))

            if is_combo:
                # 下拉框行：标签在左，下拉框在右（使用 self.model_combo）
                if hasattr(self, 'model_combo'):
                    row.addWidget(self.model_combo, 1)
                lay.addLayout(row)
            else:
                le = QLineEdit()
                le.setObjectName(field[1])
                le.setPlaceholderText(field[2])
                if is_password:
                    le.setEchoMode(QLineEdit.Password)
                setattr(self, field[1], le)
                row.addWidget(le, 1)
                lay.addLayout(row)

        return card

    # ==================== 聊天功能 ====================

    def _text_key_press(self, event):
        """处理回车发送 / Ctrl+回车换行"""
        if event.key() == Qt.Key_Return or event.key() == Qt.Key_Enter:
            if event.modifiers() & Qt.ControlModifier:
                QTextEdit.keyPressEvent(self.text_input, event)
            else:
                self.on_send_text()
        else:
            QTextEdit.keyPressEvent(self.text_input, event)

    def _scroll_to_bottom(self):
        """滚动到聊天区底部"""
        sb = self.chat_scroll.verticalScrollBar()
        sb.setValue(sb.maximum())

    # ==================== 消息发送与动画流程 ====================

    def on_send_text(self):
        """发送文字消息"""
        text = self.text_input.toPlainText().strip()
        if not text:
            return
        self.text_input.clear()

        bubble = ChatBubble(text, "user", theme_name=self._theme_name)
        self.chat_layout.addWidget(bubble)
        self._scroll_to_bottom()

        self._show_thinking()

        if hasattr(self.controller, 'on_text_chat'):
            thread = threading.Thread(
                target=self._do_text_chat, args=(text,), daemon=True
            )
            thread.start()

    def _show_thinking(self):
        """显示思考动画"""
        container = QWidget()
        container.setObjectName("thinkingContainer")
        row = QHBoxLayout(container)
        row.setContentsMargins(4, 6, 0, 2)

        indicator = ThinkingIndicator()
        row.addWidget(indicator)

        self.chat_layout.addWidget(container)
        self.thinking_container = container
        self._scroll_to_bottom()

    def _remove_thinking(self):
        """移除思考动画"""
        if hasattr(self, 'thinking_container') and self.thinking_container:
            for child in self.thinking_container.findChildren(ThinkingIndicator):
                child.stop()
            self.thinking_container.hide()
            self.thinking_container.deleteLater()
            self.thinking_container = None

    def _do_text_chat(self, user_text):
        """在线程中执行AI对话"""
        ai_response = None
        error_msg = None
        try:
            ai_response = self.controller.ai_model.chat(user_text)
        except Exception as e:
            print(f"[_do_text_chat] 异常: {e}")
            error_msg = str(e)

        if error_msg:
            final_text = f"⚠ 请求出错: {error_msg}"
        elif ai_response:
            final_text = ai_response
        else:
            final_text = "抱歉，未收到回复。请检查网络和API Key配置。"

        self._typewriter_signal.emit(final_text)

    @pyqtSlot(str)
    def _start_typewriter(self, full_text):
        """开始打字机效果"""
        self._remove_thinking()

        typing_bubble = TypingBubble(theme_name=self._theme_name)
        row = QHBoxLayout()
        row.setAlignment(Qt.AlignLeft)
        row.setContentsMargins(4, 2, 0, 6)
        row.addWidget(typing_bubble)

        self.chat_layout.addLayout(row)
        self.typing_bubble = typing_bubble
        self.typing_row = row
        self._scroll_to_bottom()

        self.typewriter_text = full_text
        self.typewriter_pos = 0
        self.typewriter_timer = QTimer()
        self.typewriter_timer.timeout.connect(self._typewriter_tick)
        self.typewriter_timer.start(35)

    def _typewriter_tick(self):
        """打字机效果"""
        step = 2
        self.typewriter_pos += step
        if self.typewriter_pos > len(self.typewriter_text):
            self.typewriter_pos = len(self.typewriter_text)

        displayed = self.typewriter_text[:self.typewriter_pos]
        self.typing_bubble.set_partial_text(displayed)
        self._scroll_to_bottom()

        if self.typewriter_pos >= len(self.typewriter_text):
            self.typewriter_timer.stop()
            # 打字机完成后，如果语音开关开启，播放语音回复
            self._play_chat_reply_voice(self.typewriter_text)
            self.typing_bubble = None
            self.typing_row = None

    def _on_chat_voice_toggle(self, checked):
        """文字对话面板的语音回复开关切换"""
        state = "开启" if checked else "关闭"
        print(f"[UI] 文字对话语音回复: {state}")
        if hasattr(self, 'log_panel'):
            self.log_panel.append_log("system", f"文字对话语音回复已{state}")

    def _play_chat_reply_voice(self, text):
        """播放文字回复的语音（仅当 chat_voice_btn 开启时）"""
        if not hasattr(self, 'chat_voice_btn') or not self.chat_voice_btn.isChecked():
            return
        if not hasattr(self, 'controller') or not hasattr(self.controller, 'speech_engine'):
            return
        se = self.controller.speech_engine
        if se is None:
            return
        try:
            print(f"[TTS] 播放文字回复语音 (长度={len(text)})")
            se.speak(text)
        except Exception as e:
            print(f"[TTS] 文字回复语音播放失败: {e}")

    # ==================== 公共方法 ====================

    # 状态对应的日志信息映射
    _STATUS_LOG_MSG = {
        "idle":       ("info",   "我在安静地等你，说唤醒词叫我吧"),
        "listening":  ("voice",  "我正在认真听你说话... 🎧"),
        "thinking":   ("ai",     "让我想想怎么回答你... 💭"),
        "speaking":   ("system", "正在告诉你我的想法... 🔊"),
    }

    def update_status(self, status):
        """状态变更时：更新状态标签 + 波形组件 + 日志面板"""
        self.status_label.set_status(status)
        self.status_label._current_status = status

        # 波形状态同步
        if hasattr(self, 'waveform'):
            self.waveform.set_state(status)

        # 日志面板
        if hasattr(self, 'log_panel'):
            log_type, log_msg = self._STATUS_LOG_MSG.get(
                status, ("info", f"状态变更为: {status}")
            )
            self.log_panel.append_log(log_type, log_msg)

    def update_waveform(self, volume: float):
        """
        更新波形组件音量（由语音识别引擎调用）。
        :param volume: 0.0 ~ 1.0 音量级别
        """
        if hasattr(self, 'waveform'):
            self.waveform.set_volume(volume)

    def append_chat(self, role, message):
        """添加聊天气泡（供信号调用，兼容语音模式）"""
        bubble = ChatBubble(message, role, theme_name=self._theme_name)
        self.chat_layout.addWidget(bubble)
        self._scroll_to_bottom()

    def update_video_frame(self, image):
        pix = QPixmap.fromImage(image)
        self._original_pixmap = pix  # 保存原始图供 resize 用
        scaled = pix.scaled(self.video_label.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
        self.video_label.setPixmap(scaled)
        self.video_label.setText("")

    def _show_first_frame(self, video_path):
        """提取视频第一帧显示在主页 video_label 作为封面"""
        try:
            cap = cv2.VideoCapture(video_path)
            if not cap.isOpened():
                print(f"[UI] 无法打开视频: {video_path}")
                return
            ret, frame = cap.read()
            cap.release()
            if not ret or frame is None:
                return
            # BGR -> RGB -> QImage -> QPixmap
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            h, w, ch = rgb.shape
            qimg = QImage(rgb.data, w, h, ch * w, QImage.Format_RGB888)
            pix = QPixmap.fromImage(qimg)
            self._original_pixmap = pix  # 保存原始图供 resize 用
            scaled = pix.scaled(
                self.video_label.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation
            )
            self.video_label.setPixmap(scaled)
            self.video_label.setText("")
            # 延迟重绘：等窗口布局完成后用真实尺寸重新适配
            QTimer.singleShot(100, self._refit_video_pixmap)
        except Exception as e:
            print(f"[UI] 提取视频首帧失败: {e}")

    def _refit_video_pixmap(self):
        """用 label 实际尺寸重新缩放图片（解决启动时布局未完成的尺寸偏差）"""
        if hasattr(self, '_original_pixmap') and self._original_pixmap and not self._original_pixmap.isNull():
            lbl_size = self.video_label.size()
            if lbl_size.width() > 200:  # 确认布局已完成
                scaled = self._original_pixmap.scaled(lbl_size, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                self.video_label.setPixmap(scaled)

    def load_settings(self, settings):
        """加载设置到界面控件"""
        self._load_settings_to_widgets(settings)

    def _load_settings_to_widgets(self, settings):
        """将设置值填入各控件"""
        self.wake_word_input.setText(settings.get("wake_word", ""))
        self.wake_response_input.setText(settings.get("wake_response", ""))

        # ---- 加载TTS音色配置 ----
        tts_engine = settings.get("tts_engine", "baidu")
        baidu_vid = settings.get("baidu_voice_id", 111)
        tts_speed = settings.get("tts_speed", 5)
        tts_pitch = settings.get("tts_pitch", 5)

        if hasattr(self, 'tts_engine_combo'):
            self.tts_engine_combo.blockSignals(True)
            self.tts_engine_combo.setCurrentIndex(0 if tts_engine == "baidu" else 1)
            self.tts_engine_combo.blockSignals(False)
            # 同步音色选择区域启用状态
            self._on_tts_engine_changed(self.tts_engine_combo.currentIndex())

        if hasattr(self, 'baidu_voice_combo'):
            self.baidu_voice_combo.blockSignals(True)
            # 查找匹配的音色ID
            idx = 0
            for i in range(self.baidu_voice_combo.count()):
                if self.baidu_voice_combo.itemData(i) == baidu_vid:
                    idx = i
                    break
            self.baidu_voice_combo.setCurrentIndex(idx)
            self.baidu_voice_combo.blockSignals(False)
            self._on_baidu_voice_changed(idx)

        if hasattr(self, 'speed_slider'):
            self.speed_slider.blockSignals(True)
            self.speed_slider.setValue(tts_speed)
            self.speed_slider.blockSignals(False)
            self.speed_value_lbl.setText(str(tts_speed))

        if hasattr(self, 'pitch_slider'):
            self.pitch_slider.blockSignals(True)
            self.pitch_slider.setValue(tts_pitch)
            self.pitch_slider.blockSignals(False)
            self.pitch_value_lbl.setText(str(tts_pitch))

        model_index = 0 if settings.get("ai_model") == "deepseek" else 1
        # 屏蔽所有选择器信号，避免初始化时触发不必要的回调
        self.model_combo.blockSignals(True)
        self.model_combo.setCurrentIndex(model_index)
        self.model_combo.blockSignals(False)
        if hasattr(self, 'chat_model_combo'):
            self.chat_model_combo.blockSignals(True)
            self.chat_model_combo.setCurrentIndex(model_index)
            self.chat_model_combo.blockSignals(False)

        api_keys = settings.get("api_keys", {})
        self.deepseek_key_input.setText(api_keys.get("deepseek", ""))
        self.doubao_key_input.setText(api_keys.get("doubao", ""))
        self.baidu_app_id_input.setText(api_keys.get("baidu_app_id", ""))
        self.baidu_api_key_input.setText(api_keys.get("baidu_api_key", ""))
        self.baidu_secret_key_input.setText(api_keys.get("baidu_secret_key", ""))

        # ---- STT引擎选择 ----
        if hasattr(self, 'stt_engine_combo'):
            stt_engine = settings.get("stt_engine", "baidu")
            self.stt_engine_combo.blockSignals(True)
            self.stt_engine_combo.setCurrentIndex(0 if stt_engine == "baidu" else 1)
            self.stt_engine_combo.blockSignals(False)
            self._on_stt_engine_changed(self.stt_engine_combo.currentIndex())

        current_model = settings.get("ai_model", "deepseek")
        current_key = api_keys.get(current_model, "")
        if hasattr(self, 'api_status_label'):
            t = THEMES.get(self._theme_name, THEMES["light"])
            if current_key:
                self.api_status_label.setText("已配置")
                self.api_status_label.setStyleSheet(f"color:{t['api_ok_color']}; font-size:11px;")
            else:
                self.api_status_label.setText("未配置")
                self.api_status_label.setStyleSheet(f"color:{t['api_err_color']}; font-size:11px;")

        vp = settings.get("video_path", "")
        if vp and os.path.exists(vp):
            self.video_path_label.setText(os.path.basename(vp))
            self._selected_video_path = vp
            self._show_first_frame(vp)  # 显示首帧封面
        self.timeout_spin.setValue(settings.get("idle_timeout", 5))

        # 联网搜索开关
        if hasattr(self, 'web_search_combo'):
            ws_enabled = settings.get("web_search_enabled", True)
            self.web_search_combo.blockSignals(True)
            self.web_search_combo.setCurrentIndex(0 if ws_enabled else 1)
            self.web_search_combo.blockSignals(False)

        # 外观主题
        if hasattr(self, 'theme_combo'):
            theme_setting = settings.get("theme", "system")
            self.theme_combo.blockSignals(True)
            theme_map = {"system": 0, "light": 1, "dark": 2}
            self.theme_combo.setCurrentIndex(theme_map.get(theme_setting, 0))
            self.theme_combo.blockSignals(False)
            # 应用主题
            self._theme_name = self._resolve_theme(theme_setting)
            self._apply_global_stylesheet()

        # 文字对话语音回复开关
        if hasattr(self, 'chat_voice_btn'):
            chat_voice = settings.get("chat_voice_enabled", True)
            self.chat_voice_btn.blockSignals(True)
            self.chat_voice_btn.setChecked(chat_voice)
            self.chat_voice_btn.blockSignals(False)

        # 文字对话面板显示/隐藏
        if hasattr(self, 'chat_panel_visible_combo'):
            panel_visible = settings.get("chat_panel_visible", True)
            self.chat_panel_visible_combo.blockSignals(True)
            self.chat_panel_visible_combo.setCurrentIndex(0 if panel_visible else 1)
            self.chat_panel_visible_combo.blockSignals(False)
            if hasattr(self, 'fab_chat_btn'):
                self.fab_chat_btn.setVisible(panel_visible)

    # ==================== 事件处理 ====================

    def on_manual_listen(self):
        if hasattr(self.controller, 'on_manual_listen'):
            self.controller.on_manual_listen()

    def on_stop(self):
        if hasattr(self.controller, 'on_stop'):
            self.controller.on_stop()

    def _on_log_toggle(self, checked):
        """日志开关按钮切换"""
        if checked:
            self.log_panel.show()
        else:
            self.log_panel.hide()

    def on_clear_history(self):
        while self.chat_layout.count():
            item = self.chat_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        self.thinking_container = None
        self.typing_bubble = None
        if hasattr(self.controller, 'on_clear_history'):
            self.controller.on_clear_history()

    def on_save_settings(self):
        if hasattr(self, 'chat_model_combo'):
            ai_model = "deepseek" if self.chat_model_combo.currentIndex() == 0 else "doubao"
        else:
            ai_model = "deepseek" if self.model_combo.currentIndex() == 0 else "doubao"

        # ---- 收集TTS音色参数 ----
        tts_engine_type = "baidu"
        baidu_vid = 111
        tts_spd = 5
        tts_pch = 5

        if hasattr(self, 'tts_engine_combo'):
            tts_engine_type = "baidu" if self.tts_engine_combo.currentIndex() == 0 else "local"
        if hasattr(self, 'baidu_voice_combo') and self.baidu_voice_combo.currentData():
            baidu_vid = int(self.baidu_voice_combo.currentData())
        if hasattr(self, 'speed_slider'):
            tts_spd = self.speed_slider.value()
        if hasattr(self, 'pitch_slider'):
            tts_pch = self.pitch_slider.value()

        settings = {
            "wake_word": self.wake_word_input.text(),
            "wake_response": self.wake_response_input.text(),
            "voice_gender": "female",  # 兼容旧接口（当前使用百度TTS音色替代）
            "ai_model": ai_model,
            "stt_engine": "baidu" if (hasattr(self, 'stt_engine_combo') and self.stt_engine_combo.currentIndex() == 0) else "google",
            "web_search_enabled": not (hasattr(self, 'web_search_combo') and self.web_search_combo.currentIndex() == 1),
            "video_path": "",
            "idle_timeout": self.timeout_spin.value(),
            # TTS音色参数
            "tts_engine": tts_engine_type,
            "baidu_voice_id": baidu_vid,
            "tts_speed": tts_spd,
            "tts_pitch": tts_pch,
            # 外观主题
            "theme": ["system", "light", "dark"][self.theme_combo.currentIndex()] if hasattr(self, 'theme_combo') else "system",
            # 文字对话面板设置
            "chat_voice_enabled": self.chat_voice_btn.isChecked() if hasattr(self, 'chat_voice_btn') else True,
            "chat_panel_visible": (self.chat_panel_visible_combo.currentIndex() == 0) if hasattr(self, 'chat_panel_visible_combo') else True,
            "api_keys": {
                "deepseek": self.deepseek_key_input.text(),
                "doubao": self.doubao_key_input.text(),
                "baidu_app_id": self.baidu_app_id_input.text(),
                "baidu_api_key": self.baidu_api_key_input.text(),
                "baidu_secret_key": self.baidu_secret_key_input.text(),
            }
        }
        vpt = self.video_path_label.text()
        if vpt and vpt != "未选择视频":
            # 优先使用完整路径（_selected_video_path），确保视频播放器能找到文件
            settings["video_path"] = getattr(self, '_selected_video_path', vpt)

        if hasattr(self.controller, 'on_save_settings'):
            ok = self.controller.on_save_settings(settings)
        if ok:
            self.model_combo.blockSignals(True)
            self.model_combo.setCurrentIndex(0 if ai_model == "deepseek" else 1)
            self.model_combo.blockSignals(False)
            if hasattr(self, 'chat_model_combo'):
                self.chat_model_combo.blockSignals(True)
                self.chat_model_combo.setCurrentIndex(0 if ai_model == "deepseek" else 1)
                self.chat_model_combo.blockSignals(False)
            key = settings["api_keys"].get(ai_model, "")
            t = THEMES.get(self._theme_name, THEMES["light"])
            if key:
                self.api_status_label.setText("已配置")
                self.api_status_label.setStyleSheet(f"color:{t['api_ok_color']}; font-size:11px;")
            else:
                self.api_status_label.setText("未配置")
                self.api_status_label.setStyleSheet(f"color:{t['api_err_color']}; font-size:11px;")

            # 同步TTS音色参数到控制器（实时生效）
            self._sync_tts_to_controller()

            return True

        return False

    def on_select_video(self):
        fp, _ = QFileDialog.getOpenFileName(self, "选择视频文件", "", "视频 (*.mp4 *.avi *.mov *.mkv)")
        if fp:
            self._selected_video_path = fp  # 保存完整路径（内部使用）
            self.video_path_label.setText(os.path.basename(fp))  # 界面只显示文件名
            # 提取第一帧作为封面显示在主页
            self._show_first_frame(fp)

    def on_model_changed(self, name):
        pass

    # ==================== 百度TTS音色管理 ====================

    _PREVIEW_TEXT = "你好，我是你的智能语音助手，很高兴为您服务！"

    def _on_tts_engine_changed(self, index):
        """TTS引擎切换（百度在线 <-> 本地SAPI5）"""
        is_baidu = (index == 0)
        # 控制音色选择区域的启用状态
        if hasattr(self, 'baidu_voice_combo'):
            self.baidu_voice_combo.setEnabled(is_baidu)
            self.speed_slider.setEnabled(is_baidu)
            self.pitch_slider.setEnabled(is_baidu)
        engine_name = "百度在线TTS" if is_baidu else "本地SAPI5"
        print(f"[UI] TTS引擎切换: {engine_name}")

    def _on_stt_engine_changed(self, index):
        """STT引擎切换（百度 <-> Google），控制百度凭据区域显隐"""
        is_baidu = (index == 0)
        if hasattr(self, 'baidu_stt_group'):
            self.baidu_stt_group.setVisible(is_baidu)
        engine_name = "百度STT" if is_baidu else "Google STT"
        print(f"[UI] STT引擎切换: {engine_name}")

    def _on_chat_panel_visibility_changed(self, index):
        """系统设置中文字对话面板显示/隐藏开关（实时生效，不保存）"""
        show = (index == 0)
        # 控制悬浮按钮"文字对话"的可见性
        if hasattr(self, 'fab_chat_btn'):
            self.fab_chat_btn.setVisible(show)
        state = "显示" if show else "隐藏"
        print(f"[UI] 文字对话面板按钮: {state}")
        if hasattr(self, 'log_panel'):
            self.log_panel.append_log("system", f"文字对话面板入口已{state}")

    def _on_baidu_voice_changed(self, index):
        """音色下拉框切换 -> 更新当前音色标签 + 同步到引擎"""
        if index < 0:
            return
        vid = self.baidu_voice_combo.currentData()
        if vid is None:
            return
        # 检查是否是付费音色（分隔线后面的）
        is_premium = any(v[0] == vid for v in Config.BAIDU_VOICES_PREMIUM)
        if is_premium:
            self.current_voice_label.setText(f"当前：$ 付费音色(需开通)")
            return  # 不同步，不允许使用
        # 查找音色名称
        voice_info = None
        for v in Config.BAIDU_VOICES_FREE:
            if v[0] == vid:
                voice_info = v
                break
        if voice_info:
            vname, desc, is_rec = voice_info[1], voice_info[2], voice_info[3]
            star = "★" if is_rec else ""
            self.current_voice_label.setText(f"当前：{star} {vname}")
        print(f"[UI] 音色选择: ID={vid}")
        # 实时同步到引擎
        self._sync_tts_to_controller()

    def _on_preview_voice(self):
        """试听按钮：用当前选中音色朗读测试文本"""
        if not hasattr(self, 'controller') or not hasattr(self.controller, 'speech_engine'):
            return

        se = self.controller.speech_engine
        if se.baidu_tts_client is None:
            return

        if self.tts_engine_combo.currentIndex() != 0:
            return

        # 获取当前选择的参数
        vid = self.baidu_voice_combo.currentData()
        if vid is None:
            return

        # 拦截付费音色
        if any(v[0] == vid for v in Config.BAIDU_VOICES_PREMIUM):
            print(f"[TTS] 音色 {vid} 为付费音色，跳过试听")
            return

        spd = self.speed_slider.value()
        pch = self.pitch_slider.value()

        # 每次试听都重新创建配置，确保生效
        se.set_tts_config(engine="baidu", voice_id=vid, speed=spd, pitch=pch)

        vname = "?"
        for v in Config.BAIDU_VOICES_FREE:
            if v[0] == vid:
                vname = v[1]
                break

        print(f"[TTS] 试听音色: {vname} (ID={vid})")
        se.speak(self._PREVIEW_TEXT)

    def _sync_tts_to_controller(self):
        """将UI上的TTS参数同步到控制器（实时生效）"""
        if not hasattr(self, 'controller') or not hasattr(self.controller, 'speech_engine'):
            return
        se = self.controller.speech_engine
        engine_type = "baidu" if self.tts_engine_combo.currentIndex() == 0 else "local"
        vid = self.baidu_voice_combo.currentData() if self.baidu_voice_combo.currentData() else 111
        spd = self.speed_slider.value()
        pch = self.pitch_slider.value()
        se.set_tts_config(
            engine=engine_type,
            voice_id=int(vid),
            speed=spd,
            pitch=pch,
        )

    def on_chat_model_changed(self, name):
        """侧边栏对话页切换模型"""
        self._sync_model_change(name)

    def on_bottom_model_changed(self, name):
        """底部状态栏切换模型"""
        self._sync_model_change(name)

    def _sync_model_change(self, name):
        """统一处理模型切换逻辑（带安全保护）"""
        if not hasattr(self, 'controller'):
            return
        type_map = {"DeepSeek": "deepseek", "豆包": "doubao"}
        model_type = type_map.get(name, "deepseek")
        api_keys = self.controller.settings.get("api_keys", {})
        api_key = api_keys.get(model_type, "")

        # 安全检查：如果正在对话循环中，先停止当前循环再切换
        if self.controller.current_status in ("listening", "thinking", "speaking"):
            print(f"[UI] 对话进行中，安全停止后切换模型 -> {model_type}")
            self.controller.is_active = False  # 通知循环退出
            import time as _t; _t.sleep(0.3)  # 等待循环线程检测到中断

        self.controller.ai_model.set_model(model_type, api_key)

        # 同步更新设置并持久化（避免重启后丢失）
        self.controller.settings["ai_model"] = model_type
        try:
            Config.save_settings(self.controller.settings)
        except Exception as e:
            print(f"[UI] 保存模型设置失败: {e}")

        # 同步所有模型选择器（blockSignals防止循环）
        idx = 0 if model_type == "deepseek" else 1

        for combo_name in ['chat_model_combo', 'model_combo']:
            combo = getattr(self, combo_name, None)
            if combo:
                combo.blockSignals(True)
                combo.setCurrentIndex(idx)
                combo.blockSignals(False)

        # 更新所有API状态标签
        t = THEMES.get(self._theme_name, THEMES["light"])
        status_text = "✅" if api_key else "❌ 未配置"
        style_color = t["api_ok_color"] if api_key else t["api_err_color"]

        if hasattr(self, 'api_status_label'):
            self.api_status_label.setText("已配置" if api_key else "未配置")
            self.api_status_label.setStyleSheet(f"color:{style_color}; font-size:11px;")
