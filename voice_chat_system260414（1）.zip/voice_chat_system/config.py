# config.py - 系统配置文件

import os
import json

class Config:
    """系统配置类"""
    
    # 项目根目录
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    
    # 资源路径
    ASSETS_DIR = os.path.join(BASE_DIR, 'assets')
    VIDEOS_DIR = os.path.join(ASSETS_DIR, 'videos')
    ICONS_DIR = os.path.join(ASSETS_DIR, 'icons')
    DATA_DIR = os.path.join(BASE_DIR, 'data')
    SETTINGS_FILE = os.path.join(DATA_DIR, 'settings.json')
    
    # 默认设置
    DEFAULT_SETTINGS = {
        "wake_word": "小智",
        "wake_response": "在的，请说",
        "voice_gender": "female",  # male 或 female
        "ai_model": "deepseek",    # deepseek 或 doubao
        "stt_engine": "baidu",      # "baidu"(百度STT) / "google"(Google STT)
        "speech_engine": "baidu",   # baidu (百度) 或 google (保留兼容)
        "web_search_enabled": True, # 联网搜索开关（默认开启）
        "video_path": "",
        "idle_timeout": 5,         # 无输入后返回待机时间（秒）
        # ---- 百度 TTS 音色参数 ----
        "tts_engine": "baidu",     # "baidu"(百度在线) / "local"(SAPI5本地)
        "baidu_voice_id": 111,     # 默认度晓晓(AI助手女声)
        "tts_speed": 5,            # 语速 0-15 (5=正常)
        "tts_pitch": 5,            # 音调 0-15 (5=正常)
        "theme": "system",         # 外观主题: "system"(跟随系统) / "light"(浅色) / "dark"(深色)
        "api_keys": {
            "deepseek": "",
            "doubao": "",
            "baidu_app_id": "",
            "baidu_api_key": "",
            "baidu_secret_key": ""
        }
    }
    
    # AI模型配置
    AI_MODELS = {
        "deepseek": {
            "name": "DeepSeek",
            "api_url": "https://api.deepseek.com/v1/chat/completions",
            "model": "deepseek-chat"
        },
        "doubao": {
            "name": "豆包",
            "api_url": "https://ark.cn-beijing.volces.com/api/v3/chat/completions",
            "model": "doubao-seed-1-8-251228"
        }
    }

    # 百度TTS音色库 (per参数 → 显示名, 描述)
    # 参考: https://ai.baidu.com/tech/speech/tts
    # 推荐标记: ★ = AI助手首选
    # 付费标记: $ = 需开通高级版/付费音色，免费用户不可用

    # ---- 免费可用音色 ----
    BAIDU_VOICES_FREE = [
        (0,   "度小美(默认女声)",     "标准女声", False),
        (1,   "度小宇(默认男声)",     "标准男声", False),
        (3,   "度逍遥(精品男声)",     "磁性男声", False),
        (4,   "度丫丫(精品女声)",     "甜美女声", False),
        (5,   "度小娇(情感女声)",     "温柔亲切", False),
        (103, "度米朵(情感女声)",     "成熟知性", False),
        (106, "度博文(精品男声)",     "新闻播音", False),
        (110, "度小宁(男童)",         "活泼男孩", True),      # ★ 首选
        (111, "★ 度晓晓(AI助手女声)","AI助手推荐", True),  # ★ 首选
        (5003, "度小新(情感男声)",    "阳光少年", False),
        (5118, "度小鹿(甜美女声)",    "可爱甜美", False),
    ]

    # ---- 付费/高级音色（免费用户不可用）----
    BAIDU_VOICES_PREMIUM = [
        (1033, "度小堂(情感男声)",     "温暖大叔 — 需开通高级版"),
    ]

    # 合并（兼容旧代码）
    BAIDU_VOICES = BAIDU_VOICES_FREE + BAIDU_VOICES_PREMIUM
    
    @staticmethod
    def load_settings():
        """加载用户设置"""
        try:
            if os.path.exists(Config.SETTINGS_FILE):
                with open(Config.SETTINGS_FILE, 'r', encoding='utf-8') as f:
                    settings = json.load(f)
                    # 合并默认设置和用户设置
                    return {**Config.DEFAULT_SETTINGS, **settings}
            else:
                Config.save_settings(Config.DEFAULT_SETTINGS)
                return Config.DEFAULT_SETTINGS.copy()
        except Exception as e:
            print(f"加载设置失败: {e}")
            return Config.DEFAULT_SETTINGS.copy()
    
    @staticmethod
    def save_settings(settings):
        """保存用户设置"""
        try:
            os.makedirs(Config.DATA_DIR, exist_ok=True)
            with open(Config.SETTINGS_FILE, 'w', encoding='utf-8') as f:
                json.dump(settings, f, ensure_ascii=False, indent=4)
            return True
        except Exception as e:
            print(f"保存设置失败: {e}")
            return False