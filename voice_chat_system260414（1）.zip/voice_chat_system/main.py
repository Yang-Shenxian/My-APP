# main.py - 主程序入口

import sys
import traceback
from PyQt5.QtWidgets import QApplication
from PyQt5.QtCore import QTimer, QObject, pyqtSignal
from ui.main_window import MainWindow
from modules.wake_word import WakeWordDetector
from modules.speech_engine import SpeechEngine
from modules.ai_model import AIModel
from modules.video_player import VideoPlayer
from config import Config
import threading
import time

class VoiceAssistantController(QObject):
    """语音助手控制器"""

    # 信号
    status_changed = pyqtSignal(str)
    chat_message = pyqtSignal(str, str)  # role, message
    log_message = pyqtSignal(str, str)   # (log_type, message) → 日志面板
    search_status = pyqtSignal(str, str)  # ("searching"|"idle", keyword|result) → 联网状态
    
    def __init__(self):
        super().__init__()
        
        # 加载配置
        self.settings = Config.load_settings()
        
        # 初始化模块
        self.wake_detector = WakeWordDetector(
            wake_word=self.settings["wake_word"],
            callback=self.on_wake_word_detected
        )
        
        self.speech_engine = SpeechEngine()
        self.speech_engine.set_voice_gender(self.settings["voice_gender"])
        
        # 加载百度TTS音色配置（如果已设置）
        tts_engine = self.settings.get("tts_engine", "baidu")
        baidu_vid = self.settings.get("baidu_voice_id", 111)
        tts_speed = self.settings.get("tts_speed", 5)
        tts_pitch = self.settings.get("tts_pitch", 5)
        self.speech_engine.set_tts_config(
            engine=tts_engine,
            voice_id=baidu_vid,
            speed=tts_speed,
            pitch=tts_pitch
        )
        
        # 设置百度语音识别凭据（仅当 STT 引擎为百度时）
        stt_engine = self.settings.get("stt_engine", "baidu")
        baidu_keys = self.settings.get("api_keys", {})
        app_id = baidu_keys.get("baidu_app_id", "")
        api_key = baidu_keys.get("baidu_api_key", "")
        secret_key = baidu_keys.get("baidu_secret_key", "")
        
        if stt_engine == "baidu" and app_id and api_key and secret_key:
            self.wake_detector.set_baidu_credentials(app_id, api_key, secret_key)
            self.speech_engine.set_baidu_credentials(app_id, api_key, secret_key)
        
        # 初始化AI模型
        model_type = self.settings["ai_model"]
        api_key = self.settings["api_keys"].get(model_type, "")
        self.ai_model = AIModel(model_type=model_type, api_key=api_key)
        
        # 配置联网搜索
        search_enabled = self.settings.get("web_search_enabled", True)
        self.ai_model.enable_search(search_enabled)
        self.ai_model.set_search_callback(
            on_start=lambda kw: self.search_status.emit("searching", kw),
            on_done=lambda res: self.search_status.emit("idle", res if res else "无结果")
        )
        
        # 视频播放器
        self.video_player = VideoPlayer(self.settings.get("video_path", ""))
        
        # 状态
        self.current_status = "idle"  # idle, listening, thinking, speaking
        self.is_active = False  # 是否已唤醒
        self.idle_timer = None
        
    def _log(self, log_type, message):
        """发送日志到UI面板（同时保留print到控制台）"""
        print(f"[{log_type.upper()}] {message}")
        self.log_message.emit(log_type, message)

    def start(self):
        """启动助手"""
        self._log("system", "小智已准备就绪，说「%s」唤醒我吧" % self.settings.get('wake_word', '小智'))
        self.wake_detector.start_listening()
        self.update_status("idle")
        
    def update_status(self, status):
        """更新状态"""
        self.current_status = status
        self.status_changed.emit(status)
        
    def on_wake_word_detected(self):
        """检测到唤醒词"""
        self._log("voice", "听到你啦，我在呢～")
        self.is_active = True
        self.update_status("speaking")

        # 停止监听唤醒词
        self.wake_detector.stop_listening()

        # 【优化】提前启动麦克风校准（与TTS并行，节省 ~1s）
        self._calib_thread = threading.Thread(target=self.speech_engine.calibrate_once, daemon=True)
        self._calib_thread.start()

        # 播放唤醒回复（TTS结束后立刻进入对话循环）
        wake_response = self.settings.get("wake_response", "在的，请说")
        self.speech_engine.speak(wake_response, callback=self.after_wake_response)

    def after_wake_response(self):
        """唤醒回复后，等待校准完成（通常已完成），进入持续对话循环"""
        self._log("system", "好的，请开始说话，我随时在听～")
        # 等待校准线程结束（已并行执行过，大概率已完成）
        if hasattr(self, '_calib_thread') and self._calib_thread.is_alive():
            self._log("system", "准备中，马上就好...")
            self._calib_thread.join(timeout=0.5)
        # 启动对话循环线程（整个唤醒期间只启动一次）
        thread = threading.Thread(target=self._conversation_loop, daemon=True)
        thread.start()

    def _conversation_loop(self):
        """
        持续对话循环：监听→AI回复→播报→立即回到监听（零延迟）。
        整个循环在同一个线程中运行，避免每次重新创建线程和校准麦克风的延迟。
        唤醒词触发后调用一次，直到超时或用户停止才退出。
        """
        while self.is_active:
            try:
                # ---- 阶段1: 监听用户语音 ----
                self.update_status("listening")
                t0 = time.time()
                user_text = self.speech_engine.listen(
                    timeout=self.settings.get("idle_timeout", 8),
                    skip_calibration=True   # 跳过校准，直接监听
                )
                t1 = time.time()

                if not user_text:
                    # 监听超时或无有效输入，返回待机
                    self._log("system", "没听到声音，我继续等你的唤醒词～")
                    self.return_to_idle()
                    return

                # 显示用户问题
                self._log("voice", f"听到了：{user_text}")
                self.chat_message.emit("user", user_text)

                # ---- 阶段2: AI生成回复 ----
                self.update_status("thinking")
                self._log("ai", "让我想想...")
                ai_response = self.ai_model.chat(user_text)
                t2 = time.time()

                if not ai_response:
                    ai_response = "抱歉，我没有生成回复。"
                self._log("ai", "想好啦，这就告诉你～")
                self.chat_message.emit("assistant", ai_response)

                # ---- 阶段3: TTS 播报 + 视频播放 ----
                self.update_status("speaking")
                self.start_video()

                # 用事件同步等待 TTS 结束（非阻塞式等待）
                speak_done_event = threading.Event()

                def on_speak_complete():
                    speak_done_event.set()

                self.speech_engine.speak(ai_response, callback=on_speak_complete)

                # 等待 TTS 完成（同时检查是否被中断）
                while not speak_done_event.is_set():
                    if not self.is_active:
                        # 用户手动停止了
                        self._log("system", "好的，已停止，随时可以再叫我～")
                        self.stop_video()
                        return
                    speak_done_event.wait(timeout=0.1)  # 每100ms检查一次中断标志

                # TTS 正常结束，继续下一轮
                self.stop_video()
                self._log("system", "说完啦，我继续听你说话～")

            except Exception as e:
                # 捕获任何异常，防止线程静默死亡
                self._log("error", f"哎呀，出了点小问题：{e}")
                print(f"[对话循环异常] {type(e).__name__}: {e}")
                import traceback
                traceback.print_exc()
                # 尝试恢复：停止视频、重置状态
                try:
                    self.stop_video()
                except Exception:
                    pass
                # 继续下一轮而不是退出
                self._log("system", "我正在重新准备，请再说一次～")
        
    def return_to_idle(self):
        """返回待机状态（非阻塞方式）"""
        self.is_active = False
        # 重置语音引擎校准状态（下次唤醒时重新校准）
        self.speech_engine.reset_calibration()
        # 重置唤醒词检测器的能量阈值（适中值，下次校准自适应）
        self.wake_detector.recognizer.energy_threshold = 600
        self.wake_detector.recognizer.dynamic_energy_threshold = True
        # 非阻塞停止视频
        if self.video_player.isRunning():
            self.video_player.stop()
        if self.video_player.isRunning():
            self.video_player.wait(500)
        self.update_status("idle")
        
        # 重新开始监听唤醒词
        self.wake_detector.set_wake_word(self.settings["wake_word"])
        self.wake_detector.start_listening()
        
    def start_video(self):
        """开始播放视频"""
        if self.settings.get("video_path"):
            self.video_player.set_video(self.settings["video_path"])
            if not self.video_player.isRunning():
                self.video_player.start()
                
    def stop_video(self):
        """停止视频"""
        if self.video_player.isRunning():
            self.video_player.stop()
            self.video_player.wait()
            
    def on_manual_listen(self):
        """手动提问"""
        if self.current_status == "idle":
            self.on_wake_word_detected()
        elif self.current_status == "listening":
            pass
        else:
            print("当前状态不允许手动提问")

    def on_text_chat(self, user_message):
        """文字对话 - 直接与AI交互，返回回复文本（在线程中调用）"""
        self._log("ai", "收到你的消息，正在思考...")
        # 不再发射用户消息（界面已经显示了）
        self.update_status("thinking")
        response = self.ai_model.chat(user_message)
        self.chat_message.emit("assistant", response)
        self.update_status("idle")
        return response

    def on_stop(self):
        """停止播报（非阻塞方式，避免卡死UI）"""
        self.speech_engine.stop_speaking()
        # 停止视频：不阻塞主线程，用标志位让播放器自行退出
        if self.video_player.isRunning():
            self.video_player.stop()
        # 短延时等待视频线程自然退出（最多500ms，不阻塞）
        if self.video_player.isRunning():
            self.video_player.wait(500)
        # 重置状态，防止回调再次触发
        self.is_active = False
        self.current_status = "idle"
        # 重置语音引擎校准和阈值（防止下次唤醒时阈值异常）
        self.speech_engine.reset_calibration()
        self.update_status("idle")
        # 重新开始监听唤醒词
        self.wake_detector.set_wake_word(self.settings["wake_word"])
        self.wake_detector.start_listening()
        
    def on_clear_history(self):
        """清空对话历史"""
        self.ai_model.clear_history()
        
    def on_save_settings(self, settings):
        """保存设置"""
        # 保存到文件
        success = Config.save_settings(settings)
        
        if success:
            # 更新当前设置
            self.settings = settings
            
            # 更新各模块
            self.wake_detector.set_wake_word(settings["wake_word"])
            self.speech_engine.set_voice_gender(settings["voice_gender"])
            
            model_type = settings["ai_model"]
            api_key = settings["api_keys"].get(model_type, "")
            self.ai_model.set_model(model_type, api_key)
            self.ai_model.enable_search(settings.get("web_search_enabled", True))
            
            self.video_player.set_video(settings.get("video_path", ""))
            
            # 更新百度语音识别凭据
            stt_engine = settings.get("stt_engine", "baidu")
            baidu_keys = settings.get("api_keys", {})
            app_id = baidu_keys.get("baidu_app_id", "")
            api_key = baidu_keys.get("baidu_api_key", "")
            secret_key = baidu_keys.get("baidu_secret_key", "")
            if stt_engine == "baidu" and app_id and api_key and secret_key:
                self.wake_detector.set_baidu_credentials(app_id, api_key, secret_key)
                self.speech_engine.set_baidu_credentials(app_id, api_key, secret_key)
            else:
                # 切换到 Google STT 时清空百度客户端，强制走 Google
                self.wake_detector.set_baidu_credentials("", "", "")
                self.speech_engine.set_baidu_credentials("", "", "")
            
        return success

def main():
    """主函数"""
    # 全局未捕获异常处理（防止静默闪退）
    sys.excepthook = lambda *args: (
        print("\n=== 程序异常崩溃 ===", file=sys.stderr),
        traceback.print_exception(*args),
        input("\n按回车键退出...")
    )

    # 捕获子线程中的未处理异常
    import threading
    _orig_thread_ex = threading.excepthook

    def _thread_excepthook(args):
        print("\n=== 线程异常崩溃 ===", file=sys.stderr)
        traceback.print_exception(args.exc_type, args.exc_value, args.exc_traceback)
        input("\n按回车键退出...")

    threading.excepthook = _thread_excepthook

    app = QApplication(sys.argv)

    # 设置应用样式
    app.setStyle('Fusion')
    
    # 创建控制器
    controller = VoiceAssistantController()
    
    # 创建主窗口
    window = MainWindow(controller)
    
    # 连接信号
    controller.status_changed.connect(window.update_status)
    controller.chat_message.connect(window.append_chat)
    controller.video_player.frame_signal.connect(window.update_video_frame)
    controller.log_message.connect(lambda t, m: window.log_panel.append_log(t, m) if hasattr(window, 'log_panel') else None)  # 日志面板
    controller.search_status.connect(lambda status, info: window.on_search_status(status, info))  # 联网状态
    controller.video_player.error_signal.connect(lambda msg: (
        print(f"[视频] {msg}"),
        window.log_panel.append_log("error", f"视频: {msg}") if hasattr(window, 'log_panel') else None
    ))
    
    # 加载设置到界面
    window.load_settings(controller.settings)
    
    # 显示窗口
    window.show()
    
    # 启动助手
    controller.start()
    
    # 运行应用
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()