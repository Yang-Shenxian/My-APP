# test_mic.py - 麦克风/语音识别快速测试（不用说话）
import sys
import io
import speech_recognition as sr

# 修复 Windows 控制台编码
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')


def test_mic():
    r = sr.Recognizer()
    mic = sr.Microphone()

    print("=" * 50)
    print("  麦克风测试工具")
    print("=" * 50)

    # 1. 列出可用麦克风
    print("\n[INFO] 可用麦克风列表：")
    mic_list = sr.Microphone.list_microphone_names()
    if not mic_list:
        print("   未检测到任何麦克风设备！")
        return
    for i, name in enumerate(mic_list):
        marker = " <-- 默认" if i == 0 else ""
        print(f"   [{i}] {name}{marker}")

    # 2. 检测环境噪音
    print("\n[INFO] 正在检测环境噪音（请保持安静，约2秒）...")
    with mic as source:
        r.adjust_for_ambient_noise(source, duration=2)
        print(f"   能量阈值: {r.energy_threshold}")
        print(f"   动态阈值: {r.dynamic_energy_threshold}")

    # 3. 监听测试
    print(f"\n[LISTEN] 开始监听 10 秒...")
    print("   请在 10 秒内做以下任一操作：")
    print("     1) 拍一下手")
    print("   2) 敲几下键盘")
    print("   3) 或者小声说句话")

    with mic as source:
        try:
            audio = r.listen(source, timeout=10, phrase_time_limit=8)
            duration = len(audio.get_raw_data()) / 16000
            print(f"\n[OK] 录音成功！音频时长 ~{duration:.1f}秒")

            # 尝试识别
            print("\n[PROCESS] 正在调用 Google 语音识别 API ...")
            try:
                text = r.recognize_google(audio, language='zh-CN')
                print(f'   [RESULT] 识别结果: "{text}"')
            except sr.UnknownValueError:
                print("   [WARN] 录到了声音但无法识别为文字")
                print("          (拍手/敲键没有文字内容是正常的)")
                print("   [PASS] 麦克风 -> 音频采集 -> 网络传输 全链路通畅！")

            # 保存录音文件
            wav_path = "test_recording.wav"
            with open(wav_path, "wb") as f:
                f.write(audio.get_wav_data())
            print(f"\n[SAVE] 录音已保存: {wav_path} (可用播放器打开检查)")

        except sr.WaitTimeoutError:
            print("\n[FAIL] 超时！没有任何声音被录入")
            print("   可能原因：")
            print("   - 麦克风被禁用或未连接")
            print("   - 应用没有麦克风权限")
            print("   - 麦克风音量太低")
            print("   建议：先试试 Windows 录音机 (Win+R -> sndrec32)")
        except Exception as e:
            print(f"\n[ERROR] {type(e).__name__}: {e}")


if __name__ == "__main__":
    test_mic()
