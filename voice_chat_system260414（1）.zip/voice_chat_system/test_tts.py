# test_tts.py - 测试语音合成（TTS）是否正常
import sys
import io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

import pyttsx3

print("=" * 50)
print("  TTS 语音合成测试")
print("=" * 50)

engine = pyttsx3.init()

# 1. 列出所有可用语音
voices = engine.getProperty('voices')
print(f"\n[INFO] 系统可用语音 ({len(voices)} 个):")
for i, v in enumerate(voices):
    lang = ""
    try:
        # 有些系统可以获取语言信息
        lang = f" [Lang={v.languages}]"
    except:
        pass
    print(f"   [{i}] {v.name}{lang}")
    print(f"       ID: {v.id}")

# 2. 当前使用的语音
current_voice = engine.getProperty('voice')
rate = engine.getProperty('rate')
volume = engine.getProperty('volume')
print(f"\n[INFO] 当前设置:")
print(f"       语音: {current_voice}")
print(f"       语速: {rate}")
print(f"       音量: {volume}")

# 3. 尝试播报中文测试
test_text = "你好，我是AI语音助手，这是一段测试语音。"
print(f"\n[TTS] 即将播报: \"{test_text}\"")
print("      请听声音是否正常...")
print("-" * 50)

engine.setProperty('rate', 180)
engine.setProperty('volume', 0.9)

# 尝试选择一个支持中文的语音
# 在Windows上通常需要选中文语音
chinese_voice_found = False
for i, v in enumerate(voices):
    vid = v.id.lower()
    vname = v.name.lower()
    if any(kw in vid or kw in vname for kw in ['chinese', 'huihui', 'xiaoxiao', 'yunyang', 'yunxi', 'zh-CN', 'zh_cn']):
        print(f"[OK] 找到中文语音: {v.name} (索引={i})")
        engine.setProperty('voice', v.id)
        chinese_voice_found = True
        break

if not chinese_voice_found and len(voices) > 1:
    # 如果没明确找到中文的，用第二个（通常是女声）
    engine.setProperty('voice', voices[1].id)
    print(f"[WARN] 未明确找到中文语音，使用: {voices[1].name}")

engine.say(test_text)
engine.runAndWait()

print("-" * 50)
print("[DONE] 播报完成，请确认听到的内容是否是上面那段中文")
