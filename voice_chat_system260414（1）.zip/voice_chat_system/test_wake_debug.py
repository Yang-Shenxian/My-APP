# test_wake_debug.py - 唤醒词链路诊断脚本
import sys
import io
import speech_recognition as sr
import time

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')


def diagnose():
    r = sr.Recognizer()
    # 用测试中检测到的合理阈值
    r.energy_threshold = 1500
    r.dynamic_energy_threshold = True
    r.pause_threshold = 0.8
    mic = sr.Microphone()

    print("=" * 55)
    print("  唤醒词链路诊断工具")
    print("=" * 55)
    print(f"\n当前配置:")
    print(f"  energy_threshold: {r.energy_threshold}")
    print(f"  dynamic_energy:   {r.dynamic_energy_threshold}")
    print(f"  pause_threshold:  {r.pause_threshold}")
    print(f"  唤醒词:          小智")

    # 阶段1: 环境噪音校准
    print(f"\n[阶段1] 校准环境噪音（请安静 2 秒）...")
    with mic as source:
        r.adjust_for_ambient_noise(source, duration=2)
        print(f"  校准后阈值: {r.energy_threshold}")

    # 阶段2: 循环监听，打印每次识别结果
    print(f"\n[阶段2] 开始循环监听（共 30 秒，或 Ctrl+C 停止）")
    print(f"  请对着麦克风说话，每句话都会显示识别结果")
    print(f"  试着说 '小智' 或其他任何话")
    print(f"-" * 55)

    start_time = time.time()
    attempt = 0

    while time.time() - start_time < 30:
        attempt += 1
        try:
            with mic as source:
                print(f"\n[#{attempt}] 等待语音输入...", end=" ", flush=True)
                audio = r.listen(source, timeout=None, phrase_time_limit=5)

            raw_size = len(audio.get_raw_data())
            duration = raw_size / 16000
            print(f"录到音频 ({duration:.1f}s, {raw_size} bytes)")

            # 尝试 Google 识别
            print(f"       正在调用 Google 识别...", end=" ", flush=True)
            try:
                text = r.recognize_google(audio, language='zh-CN')
                print(f'成功! -> "{text}"')

                if "小智" in text.lower():
                    print(f"       *** 匹配唤醒词! ***")
                    # 这里可以加回调逻辑

            except sr.UnknownValueError:
                print("失败 -> 录到声音但无法识别(可能是杂音)")
            except sr.RequestError as e:
                print(f"失败 -> 网络错误: {e}")
                print(f"       >>> 这说明 Google 语音服务不可达! <<<")
                print(f"       >>> 可能需要代理/VPN, 或换用其他识别引擎 <<<")
                return "network_error"

        except sr.WaitTimeoutError:
            print("超时(无声音)")
        except Exception as e:
            print(f"异常: {type(e).__name__}: {e}")

    print(f"\n{'=' * 55}")
    print(f"诊断结束，共尝试 {attempt} 次")
    print(f"如果你看到 '网络错误'，说明 Google 服务不可用")
    print(f"如果你看到全是 '超时'，说明麦克风没收到声音")
    print(f"{'=' * 55}")
    return "ok"


if __name__ == "__main__":
    result = diagnose()
    if result == "network_error":
        print("\n[建议] Google 语音识别在你的网络环境下不可用")
        print("  解决方案:")
        print("  1. 开启 VPN/代理后重试")
        print("  2. 或者我可以帮你换成百度/讯飞等国内可用的语音识别")
