# modules/web_search.py - 联网搜索模块（免费，无需API Key）

import re
import requests
from urllib.parse import quote


# ── 中国主要城市坐标（用于 Open-Meteo 天气 API）─────────
_CITY_COORDS = {
    # 直辖市
    "北京": (39.9042, 116.4074),
    "上海": (31.2304, 121.4737),
    "天津": (39.0842, 117.2009),
    "重庆": (29.4316, 106.9123),
    # 省会/重点城市
    "广州": (23.1291, 113.2644),
    "深圳": (22.5431, 114.0579),
    "郑州": (34.7466, 113.6253),
    "武汉": (30.5928, 114.3055),
    "西安": (34.3416, 108.9398),
    "成都": (30.5728, 104.0668),
    "杭州": (30.2741, 120.1551),
    "南京": (32.0603, 118.7969),
    "长沙": (28.2282, 112.9388),
    "济南": (36.6510, 117.1201),
    "青岛": (36.0671, 120.3826),
    "大连": (38.9140, 121.6147),
    "沈阳": (41.8057, 123.4328),
    "长春": (43.8171, 125.3235),
    "哈尔滨": (45.8038, 126.5350),
    "石家庄": (38.0428, 114.5149),
    "太原": (37.8706, 112.5489),
    "合肥": (31.8206, 117.2272),
    "福州": (26.0745, 119.2965),
    "厦门": (24.4798, 118.0894),
    "南昌": (28.6820, 115.8579),
    "南宁": (22.8170, 108.3665),
    "海口": (20.0440, 110.1999),
    "贵阳": (26.6470, 106.6302),
    "昆明": (25.0389, 102.7183),
    "兰州": (36.0611, 103.8343),
    "银川": (38.4872, 106.2309),
    "西宁": (36.6171, 101.7782),
    "乌鲁木齐": (43.8256, 87.6168),
    "呼和浩特": (40.8426, 111.7500),
    "拉萨": (29.6500, 91.1000),
    # 常见地级市
    "苏州": (31.2990, 120.5853),
    "无锡": (31.4912, 120.3119),
    "宁波": (29.8696, 121.5440),
    "温州": (27.9939, 120.6994),
    "东莞": (23.0207, 113.7518),
    "佛山": (23.0218, 113.1217),
    "珠海": (22.2711, 113.5766),
    "洛阳": (34.6197, 112.4540),
    "开封": (34.7972, 114.3088),
    "南阳": (32.9900, 112.5350),
    # 国际城市
    "东京": (35.6762, 139.6503),
    "纽约": (40.7128, -74.0060),
    "伦敦": (51.5074, -0.1278),
    "巴黎": (48.8566, 2.3522),
}

# WMO 天气代码 → 中文描述
_WMO_WEATHER = {
    0: "晴", 1: "大部晴朗", 2: "多云", 3: "阴天",
    45: "雾", 48: "雾凇",
    51: "小毛毛雨", 53: "中毛毛雨", 55: "大毛毛雨",
    61: "小雨", 63: "中雨", 65: "大雨",
    71: "小雪", 73: "中雪", 75: "大雪",
    77: "雪粒", 80: "阵雨", 81: "强阵雨", 82: "暴雨",
    85: "阵雪", 86: "大阵雪",
    95: "雷暴", 96: "雷暴+小冰雹", 99: "雷暴+大冰雹",
}


class WebSearchService:
    """轻量联网搜索服务 — 通过 DuckDuckGo 获取实时信息"""

    # 需要实时信息的关键词（用于判断是否触发搜索）
    _REALTIME_KEYWORDS = [
        # 天气类
        "天气", "温度", "气温", "下雨", "晴天", "阴天", "多云", "雪", "台风",
        "湿度", "风力", "空气质量", "pm2.5", "雾霾", "紫外线",
        "几度", "多少度", "零下", "摄氏",
        # 新闻/时事类
        "新闻", "热点", "头条", "最新", "今天发生", "刚刚", "突发",
        "事件", "发布会", "比赛结果", "比分", "战况",
        # 时间日期类（已有时间上下文，但搜索可补充节假日等）
        "节假日", "放假", "调休", "星期几",
        # 地点/查询类
        "怎么去", "路线", "交通", "航班", "火车", "高铁", "公交",
        "附近", "地址", "营业时间", "开门", "关门",
        # 数据/价格类
        "价格", "多少钱", "汇率", "股票", "彩票",
    ]

    def __init__(self):
        self.enabled = True
        self._session = requests.Session()
        self._session.headers.update({
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        })

    @staticmethod
    def needs_realtime_info(text: str) -> bool:
        """
        判断用户问题是否需要实时信息。
        返回 True 则触发联网搜索。
        """
        text_lower = text.lower().strip()
        # 空白或太短不搜
        if len(text_lower) < 3:
            return False
        # 关键词匹配
        for kw in WebSearchService._REALTIME_KEYWORDS:
            if kw in text_lower:
                return True
        return False

    @staticmethod
    def _extract_city(text: str):
        """从文本中提取城市名（优先匹配长名）"""
        # 按名称长度降序排列，避免"天津"匹配到"天"
        sorted_cities = sorted(_CITY_COORDS.keys(), key=len, reverse=True)
        for city in sorted_cities:
            if city in text:
                return city
        return None

    @staticmethod
    def is_weather_query(text: str) -> bool:
        """判断是否为天气类查询"""
        text_lower = text.lower().strip()
        weather_kws = ["天气", "温度", "气温", "下雨", "晴天", "阴天", "多云",
                       "雪", "台风", "湿度", "风力", "空气质量", "pm2.5", "雾霾",
                       "紫外线", "几度", "多少度", "零下", "摄氏", "度吗", "怎么样"]
        for kw in weather_kws:
            if kw in text_lower:
                return True
        return False

    def _get_weather(self, city_name: str) -> str:
        """使用 Open-Meteo 免费天气 API 获取实时天气（无需 Key）"""
        if city_name not in _CITY_COORDS:
            return ""
        lat, lon = _CITY_COORDS[city_name]
        
        try:
            # Open-Meteo API — 免费、无限制、无需Key
            url = "https://api.open-meteo.com/v1/forecast"
            params = {
                "latitude": lat,
                "longitude": lon,
                "current": "temperature_2m,relative_humidity_2m,apparent_temperature,"
                           "weather_code,wind_speed_10m,wind_direction_10m,"
                           "surface_pressure",
                "daily": "temperature_2m_max,temperature_2m_min,weather_code,precipitation_sum",
                "timezone": "auto",
                "forecast_days": 1,
            }
            resp = self._session.get(url, params=params, timeout=10)
            resp.raise_for_status()
            data = resp.json()
            
            cur = data.get("current", {})
            daily = data.get("daily", {})
            
            # 解析当前天气
            temp = cur.get("temperature_2m")
            feels_like = cur.get("apparent_temperature")
            humidity = cur.get("relative_humidity_2m")
            wmo_code = cur.get("weather_code")
            wind_speed = cur.get("wind_speed_10m")
            pressure = cur.get("surface_pressure")
            weather_desc = _WMO_WEATHER.get(wmo_code, f"天气代码{wmo_code}")
            
            # 解析今日范围
            tmax_list = daily.get("temperature_2m_max", [])
            tmin_list = daily.get("temperature_2m_min", [])
            tmax = tmax_list[0] if tmax_list else "?"
            tmin = tmin_list[0] if tmin_list else "?"
            
            result = (
                f"【{city_name}实时天气】\n"
                f"- 天气状况：{weather_desc}\n"
                f"- 当前气温：{temp}°C（体感 {feels_like}°C）\n"
                f"- 今日温度范围：{tmin}°C ~ {tmax}°C\n"
                f"- 相对湿度：{humidity}%\n"
                f"- 风速：{wind_speed} km/h\n"
                f"- 气压：{pressure} hPa\n"
                f"(数据来源: Open-Meteo)"
            )
            return result
            
        except Exception as e:
            print(f"[WebSearch] 天气API失败: {e}")
            return ""

    def search(self, query: str, max_results: int = 3) -> str:
        """
        执行搜索，返回摘要文本。
        天气查询优先使用 Open-Meteo API（返回真实气象数据），
        其他查询使用 DuckDuckGo / Bing 搜索。
        失败时返回空字符串（调用方应降级为无搜索模式）。
        """
        if not self.enabled:
            return ""
        
        # ── 天气查询：优先走专业天气 API ──
        if self.is_weather_query(query):
            city = self._extract_city(query)
            if city:
                print(f"[WebSearch] 检测到天气查询, 城市: {city}")
                weather = self._get_weather(city)
                if weather:
                    return weather
                else:
                    print(f"[WebSearch] 天气API失败, 降级到通用搜索")
        
        # ── 通用搜索：DuckDuckGo → Bing 降级 ──
        try:
            results = self._search_duckduckgo(query, max_results)
            if results:
                return results
        except Exception as e:
            print(f"[WebSearch] DuckDuckGo 搜索失败: {e}")
        
        try:
            # 降级到 Bing 摘要
            results = self._search_bing_abstract(query)
            if results:
                return results
        except Exception as e:
            print(f"[WebSearch] Bing 搜索也失败: {e}")

        return ""

    def _search_duckduckgo(self, query: str, max_results: int = 3) -> str:
        """使用 DuckDuckGo 免费搜索"""
        url = "https://html.duckduckgo.com/html/"
        params = {"q": query}
        resp = self._session.post(url, data=params, timeout=8)
        resp.encoding = "utf-8"
        html = resp.text
        
        # 提取搜索结果（简单正则，DDG 的结果格式稳定）
        pattern = re.compile(
            r'<a[^>]+class="result__a"[^>]*href="([^"]+)"[^>]*>.*?'
            r'<a[^>]+class="result__snippet"[^>]*>(.*?)</a>',
            re.DOTALL
        )
        matches = pattern.findall(html)
        
        if not matches:
            return ""
        
        snippets = []
        seen_texts = set()
        for link, snippet_text in matches[:max_results]:
            # 清理 HTML 标签
            clean = re.sub(r'<[^>]+>', '', snippet_text).strip()
            clean = re.sub(r'\s+', ' ', clean)
            if clean and clean not in seen_texts:
                seen_texts.add(clean)
                snippets.append(clean)
        
        if not snippets:
            return ""
        
        header = f"【联网搜索结果 - 关键词: {query}】"
        body = "\n".join(f"- {s}" for s in snippets)
        return f"{header}\n{body}"

    def _search_bing_abstract(self, query: str) -> str:
        """Bing 降级方案：获取页面摘要"""
        url = f"https://cn.bing.com/search?q={quote(query)}"
        resp = self._session.get(url, timeout=8, headers={
            "Accept-Language": "zh-CN,zh;q=0.9",
        })
        resp.encoding = "utf-8"
        html = resp.text
        
        # 提取 b_algoParagraph 或 b_caption 摘要
        patterns = [
            r'<p[^>]*class="b_algoParagraph"[^>]*>(.*?)</p>',
            r'<div[^>]*class="b_caption"[^>]*>.*?<p[^>]*>(.*?)</p>',
        ]
        for pat in patterns:
            matches = re.findall(pat, html, re.DOTALL)
            if matches:
                snippets = []
                for m in matches[:3]:
                    clean = re.sub(r'<[^>]+>', '', m).strip()
                    clean = re.sub(r'\s+', ' ', clean)
                    if clean:
                        snippets.append(clean)
                if snippets:
                    header = f"【联网搜索结果 - 关键词: {query}】"
                    body = "\n".join(f"- {s}" for s in snippets)
                    return f"{header}\n{body}"
        
        return ""
