# modules/ai_model.py - AI模型接口模块（支持联网搜索）

import requests
import json
from datetime import datetime
from config import Config
from modules.web_search import WebSearchService

class AIModel:
    """AI模型接口"""
    
    # 语音对话系统提示词 — 让模型生成简短、口语化的回复
    _VOICE_SYSTEM_PROMPT = (
        "你是一个语音助手。用户通过语音与你交流（可能使用中文或英文），你的回复会被朗读出来。"
        "要求：\n"
        "1. 回复简洁明了，控制在1-3句话以内\n"
        "2. 使用口语化表达，不要用markdown格式（不用**、-列表、#标题等）\n"
        "3. 不要说emoji和特殊符号名称\n"
        "4. 直接回答问题，不要做自我介绍或罗列能力清单，除非被问到\n"
        "5. 用户可能使用中文或英文提问，请用中文回复；如果用户用英文提问（如 deepseek、AI、Python 等），正常理解并回答即可\n"
        "6. 【重要】如果用户消息中包含【联网搜索结果】，请基于搜索结果回答，不要说'我无法获取实时信息'"
    )
    
    def __init__(self, model_type="deepseek", api_key=""):
        """
        初始化AI模型
        :param model_type: 模型类型 'deepseek' 或 'doubao'
        :param api_key: API密钥
        """
        self.model_type = model_type
        self.api_key = api_key
        self.conversation_history = []
        self.model_config = Config.AI_MODELS.get(model_type, Config.AI_MODELS["deepseek"])
        
        # 联网搜索服务
        self.web_search = WebSearchService()
        self._search_callback = None   # 外部回调: on_search_start(keyword)
        self._search_done_callback = None  # 外部回调: on_search_done(result)
        
    def set_model(self, model_type, api_key):
        """
        切换模型
        :param model_type: 模型类型
        :param api_key: API密钥
        """
        self.model_type = model_type
        self.api_key = api_key
        self.model_config = Config.AI_MODELS.get(model_type, Config.AI_MODELS["deepseek"])
        self.conversation_history = []  # 切换模型时清空历史

    def enable_search(self, enabled):
        """开启/关闭联网搜索"""
        self.web_search.enabled = bool(enabled)

    def set_search_callback(self, on_start=None, on_done=None):
        """设置搜索状态回调（供UI更新状态栏）"""
        self._search_callback = on_start
        self._search_done_callback = on_done

    def chat(self, user_message):
        """
        与AI对话（自动判断是否需要联网搜索）
        :param user_message: 用户消息
        :return: AI回复
        """
        if not self.api_key:
            return "错误：未设置API密钥，请在设置中配置。"

        # ---- 联网搜索逻辑 ----
        search_result = ""
        if self.web_search.enabled and WebSearchService.needs_realtime_info(user_message):
            if self._search_callback:
                self._search_callback(user_message)
            print(f"[WebSearch] 触发联网搜索: {user_message}")
            search_result = self.web_search.search(user_message)
            if self._search_done_callback:
                self._search_done_callback(search_result)
            if search_result:
                print(f"[WebSearch] 搜索成功，结果长度: {len(search_result)}")
            else:
                print("[WebSearch] 搜索无结果，降级为普通模式")

        # 构建实际发送给模型的用户消息
        actual_message = user_message
        if search_result:
            actual_message = f"{user_message}\n\n{search_result}"

        # 添加到历史
        self.conversation_history.append({
            "role": "user",
            "content": actual_message
        })
        
        try:
            # 调用API
            response = self._call_api()
            
            if response:
                # 添加AI回复到历史
                self.conversation_history.append({
                    "role": "assistant",
                    "content": response
                })
                return response
            else:
                return "抱歉，我现在无法回答，请稍后再试。"
                
        except Exception as e:
            print(f"AI对话错误: {e}")
            return f"发生错误: {str(e)}"
            
    def _call_api(self):
        """调用AI API"""
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}"
        }
        
        # 注入当前时间上下文，让AI了解现实世界
        now = datetime.now()
        time_context = (
            f"【当前现实世界信息】今天是 {now.strftime('%Y年%m月%d日')} "
            f"{now.strftime('%A')}，{now.strftime('%H:%M')}。"
            f"请基于这个真实时间回答用户关于时间/日期的问题。"
        )
        
        data = {
            "model": self.model_config["model"],
            "messages": [
                {"role": "system", "content": self._VOICE_SYSTEM_PROMPT},
                {"role": "system", "content": time_context},
                *self.conversation_history
            ],
            "max_tokens": 300,      # 语音场景，短回复即可
            "temperature": 0.7
        }
        
        try:
            response = requests.post(
                self.model_config["api_url"],
                headers=headers,
                json=data,
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                return result['choices'][0]['message']['content']
            else:
                print(f"API错误: {response.status_code} - {response.text}")
                return None
                
        except requests.exceptions.Timeout:
            print("API请求超时")
            return None
        except Exception as e:
            print(f"API调用错误: {e}")
            return None
            
    def clear_history(self):
        """清空对话历史"""
        self.conversation_history = []
        
    def get_history(self):
        """获取对话历史"""
        return self.conversation_history.copy()