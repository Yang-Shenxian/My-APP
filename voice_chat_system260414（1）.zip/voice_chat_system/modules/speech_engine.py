# modules/speech_engine.py - 语音引擎模块
#
# TTS 架构（优先级从高到低）：
#   1. 百度智能云在线TTS（自然音色，支持多种音色/语速/音调）
#   2. Windows SAPI5 原生 COM 接口（comtypes）— 支持立即停止
#   3. 后备方案：pyttsx3（每实例模式，避免跨线程死锁）

import speech_recognition as sr
import threading
import time
import ctypes
import audioop
import re
import tempfile
import os

from aip import AipSpeech


# ============================================================
#  音频播放器 — 用于播放百度TTS返回的MP3/WAV文件
#  Windows: MCI (winmm.dll) 零依赖播放 MP3/WAV
#  其他平台: subprocess 调用系统工具
# ============================================================

class _AudioPlayer:
    """轻量音频播放器，支持 MP3/WAV，可立即停止"""

    def __init__(self):
        self._playing = False
        self._stop_requested = False
        self._alias = None  # MCI alias（Windows）

    def play(self, file_path):
        """异步播放音频文件"""
        if not os.path.exists(file_path):
            print(f"[Player] 文件不存在: {file_path}")
            return False

        import platform
        system = platform.system()
        try:
            if system == "Windows":
                return self._play_windows_mci(file_path)
            elif system == "Darwin":
                return self._play_subprocess(["afplay", file_path])
            else:
                cmd = ["mpg123", "-q", file_path] if self._find_cmd("mpg123") else ["aplay", file_path]
                return self._play_subprocess(cmd)
        except Exception as e:
            print(f"[Player] 播放失败: {e}")
            self._playing = False
            return False

    def _play_windows_mci(self, file_path):
        """使用 Windows MCI (winmm.dll) 播放音频——零依赖、支持MP3"""
        try:
            from ctypes import windll, c_wchar_p, byref
            winmm = windll.winmm

            # 生成唯一别名（基于文件名）
            self._alias = f"tts_{os.path.basename(file_path)[:8]}"

            # 打开设备
            ret = winmm.mciSendStringW(
                f'open "{file_path}" type mpegvideo alias {self._alias}',
                None, 0, None
            )
            if ret != 0:
                print(f"[Player] MCI open 失败: error={ret}, 尝试waveaudio...")
                ret = winmm.mciSendStringW(
                    f'open "{file_path}" type waveaudio alias {self._alias}',
                    None, 0, None
                )
                if ret != 0:
                    print(f"[Player] MCI waveaudio 也失败: error={ret}")

            # 播放（非阻塞，通知完成时回调）
            self._stop_requested = False
            self._playing = True
            ret = winmm.mciSendStringW(
                f'play {self._alias} notify',
                None, 0,
                0  # callback hwnd (0=不回调)
            )
            if ret != 0:
                print(f"[Player] MCI play 失败: error={ret}")
                self._playing = False
                return False

            # 轮询等待播放完毕
            while not self._stop_requested:
                buf = ctypes.create_unicode_buffer(256)
                winmm.mciSendStringW(f'status {self._alias} mode', buf, 256, None)
                mode = buf.value.strip().lower()
                if mode in ('stopped', 'not ready', ''):
                    break
                time.sleep(0.1)

            # 关闭设备
            winmm.mciSendStringW(f'close {self._alias}', None, 0, None)

            self._playing = False
            return True

        except Exception as e:
            print(f"[Player] MCI 异常: {e}")
            self._playing = False
            return False

    def _play_subprocess(self, cmd):
        """使用 subprocess 播放（macOS/Linux）"""
        import subprocess
        self._stop_requested = False
        self._playing = True
        proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        while not self._stop_requested:
            if proc.poll() is not None:
                break
            time.sleep(0.1)
        if self._stop_requested and proc.poll() is None:
            proc.terminate()
        self._playing = False
        return True

    def stop(self):
        """立即停止播放"""
        self._stop_requested = True
        self._playing = False
        if self._alias:
            try:
                from ctypes import windll
                windll.winmm.mciSendStringW(f'stop {self._alias}', None, 0, None)
                windll.winmm.mciSendStringW(f'close {self._alias}', None, 0, None)
            except Exception:
                pass
            self._alias = None

    @property
    def is_playing(self):
        return self._playing

    @staticmethod
    def _find_cmd(name):
        """查找命令是否存在"""
        import shutil
        return shutil.which(name) is not None


# ============================================================
#  百度 TTS 在线合成
# ============================================================

class _BaiduTTS:
    """
    百度智能云语音合成(TTS) — 支持多种自然音色。
    
    通过 AipSpeech.synthesis() 接口生成音频，本地缓存+播放。
    支持参数：per(音色ID), spd(语速0-15), pit(音调0-15), vol(音量0-15)
    """

    def __init__(self, client=None, voice_id=111, speed=5, pitch=5):
        """
        :param client: 已初始化的AipSpeech客户端
        :param voice_id: 音色ID（默认111=度晓晓）
        :param speed: 语速 0-15（默认5=正常）
        :param pitch: 音调 0-15（默认5=正常）
        """
        self._client = client          # AipSpeech 实例
        self.voice_id = voice_id       # 当前音色
        self.speed = speed             # 语速
        self.pitch = pitch             # 音调
        self.volume = 8                # 音量
        self._audio_player = _AudioPlayer()

    @property
    def is_available(self):
        """检查百度TTS是否可用"""
        return self._client is not None

    def synthesize(self, text):
        """
        合成语音，返回临时文件路径或None
        :return: 音频文件路径(.mp3) 或 None
        """
        if not self._client or not text:
            return None
        try:
            result = self._client.synthesis(text, 'zh', 1, {
                'per': self.voice_id,
                'spd': self.speed,
                'pit': self.pitch,
                'vol': self.volume,
            })
            # 成功时返回 bytes（二进制音频数据）
            # 失败时返回 dict（含error_code）
            if isinstance(result, dict):
                error_code = result.get('error_code', -1)
                error_msg = result.get('error_msg', '未知错误')
                raise Exception(f"百度TTS错误({error_code}): {error_msg}")

            # 写入临时文件
            tmp_fd, tmp_path = tempfile.mkstemp(suffix='.mp3')
            with os.fdopen(tmp_fd, 'wb') as f:
                f.write(result)
            return tmp_path
        except Exception as e:
            print(f"[BaiduTTS] 合成失败: {e}")
            return None

    def speak(self, text, blocking=False):
        """
        播报文本（合成+播放）
        :param text: 要朗读的文字
        :param blocking: 是否阻塞等待播放完毕
        :return: bool 是否成功开始播报
        """
        audio_file = self.synthesize(text)
        if not audio_file:
            return False

        print(f"[BaiduTTS] 正在播放 [音色{self.voice_id}]...")
        self._audio_player.play(audio_file)

        # 非阻塞模式下不能立刻删除文件，注册延迟清理
        if not blocking:
            def _cleanup():
                while self._audio_player.is_playing:
                    time.sleep(0.1)
                try:
                    if os.path.exists(audio_file):
                        os.remove(audio_file)
                except Exception:
                    pass
            threading.Thread(target=_cleanup, daemon=True).start()
        else:
            # 阻塞模式：播放完毕后删除
            try:
                if os.path.exists(audio_file):
                    os.remove(audio_file)
            except Exception:
                pass
        return True

    def stop(self):
        """停止播放"""
        self._audio_player.stop()

    def release(self):
        """释放资源（安全清理）"""
        try:
            self._audio_player.stop()
        except Exception:
            pass

    @property
    def is_playing(self):
        return self._audio_player.is_playing


# ============================================================
#  SAPI5 TTS — 使用 comtypes，支持立即停止
# ============================================================
try:
    import comtypes.client

    _SAPI_AVAILABLE = True
except ImportError:
    _SAPI_AVAILABLE = False


def _init_com_in_thread():
    """
    在当前线程初始化 COM 库。
    Windows 要求：每个使用 COM 的线程必须先调用 CoInitialize。
    返回 True 表示成功。
    """
    try:
        # COINIT_MULTITHREADED = 0x0，COINIT_APARTMENTTHREADED = 0x2
        # 使用 STA 模式（SAPI5 需要）
        result = ctypes.windll.ole32.CoInitializeEx(None, 2)
        # S_OK=0, S_FALSE=1(已初始化) 都算成功
        return result >= 0
    except Exception:
        return False


def _uninit_com():
    """释放当前线程的 COM 库"""
    try:
        ctypes.windll.ole32.CoUninitialize()
    except Exception:
        pass


class _Sapi5TTS:
    """
    SAPI5 文字转语音封装。
    
    重要：必须在已调用 CoInitialize 的线程中使用！
    
    策略：
      - speak() 用 SPF_ASYNC 异步播放（立即返回）
      - wait_until_done() 轮询 WaitUntilDone() 检测完成（不访问 RunningStream）
      - stop() 用 SVSPurgeBeforeSpeak 中断
    """

    def __init__(self, rate=180, volume=90, voice_id=None):
        self._voice = None
        self._speaking = False
        try:
            self._voice = comtypes.client.CreateObject('SAPI.SpVoice')
            # 语速映射：pyttsx3 rate 180 → SAPI rate ~-1~2
            sapi_rate = int((rate - 200) / 10)
            sapi_rate = max(-10, min(10, sapi_rate))
            self._voice.Rate = sapi_rate
            self._voice.Volume = volume
            if voice_id:
                self._set_voice_by_id(voice_id)
        except Exception as e:
            print(f"[TTS] SAPI5 初始化失败: {e}")
            self._voice = None

    def _set_voice_by_id(self, voice_id):
        if not self._voice:
            return False
        try:
            voices = self._voice.GetVoices()
            for i in range(voices.Count):
                v = voices.Item(i)
                if v.Id == voice_id:
                    self._voice.Voice = v
                    return True
        except Exception as e:
            print(f"[TTS] 设置语音失败: {e}")
        return False

    def speak(self, text):
        """
        异步播报文本（SPF_ASYNC = 1，立即返回）。
        :return: bool 是否成功开始播报
        """
        if not self._voice or not text:
            return False
        try:
            self._speaking = True
            # SVSFlagsAsync = 1
            self._voice.Speak(text, 1)
            return True
        except Exception as e:
            print(f"[TTS] speak 失败: {e}")
            self._speaking = False
            return False

    def stop(self):
        """立即中断播放（SVSFPurgeBeforeSpeak = 2）"""
        if not self._voice:
            return
        try:
            self._voice.Speak("", 2)
            self._speaking = False
        except Exception as e:
            print(f"[TTS] stop 失败: {e}")

    def wait_until_done(self, timeout_ms=100):
        """
        等待播放结束。
        使用 SAPI5 原生 WaitUntilDone API，不依赖 Status.RunningStream。
        
        :param timeout_ms: 最长等待毫秒数
        :return: True = 已完成/已停止，False = 还在播放
        """
        if not self._voice:
            return True
        try:
            # WaitUntilDone 是 SAPI5 ISpVoice 接口的标准方法
            # 返回 True 表示已完成（或队列为空），False 表示还在说
            done = self._voice.WaitUntilDone(timeout_ms)
            if done:
                self._speaking = False
            return done
        except Exception as ex:
            print(f"[TTS] WaitUntilDone 异常: {ex}")
            # 异常时认为已完成，避免卡死
            self._speaking = False
            return True

    @property
    def is_speaking(self):
        """兼容属性：反向查询是否还在说"""
        if not self._voice or not self._speaking:
            return False
        # 用短超时的 WaitUntilDone 来判断
        try:
            done = self._voice.WaitUntilDone(0)  # 立即返回
            if done:
                self._speaking = False
            return not done
        except Exception:
            self._speaking = False
            return False

    def release(self):
        """释放资源"""
        if self._voice:
            try:
                self.stop()
            except Exception:
                pass
            try:
                del self._voice
            except Exception:
                pass
            self._voice = None


def _discover_voice_id(gender='female'):
    """发现可用的中文语音 ID（需在主线程或已初始化COM的线程调用）"""
    if not _SAPI_AVAILABLE:
        return None
    try:
        voice_obj = comtypes.client.CreateObject('SAPI.SpVoice')
        voices = voice_obj.GetVoices()

        chinese_voices = []
        english_female = None
        english_male = None

        for i in range(voices.Count):
            v = voices.Item(i)
            vid_lower = v.Id.lower()
            name_lower = v.GetDescription().lower()

            if any(kw in vid_lower or kw in name_lower
                   for kw in ['zh-cn', 'zh_cn', 'chinese', 'huihui', 'xiaoxiao',
                              'yunyang', 'yunxi', 'yaoyao']):
                chinese_voices.append((v.Id, v.GetDescription()))
            elif 'zira' in vid_lower or 'zira' in name_lower:
                english_female = v.Id
            elif 'david' in vid_lower or 'david' in name_lower:
                english_male = v.Id

        del voice_obj

        if chinese_voices:
            print(f"[TTS] 选择中文语音: {chinese_voices[0][1]}")
            return chinese_voices[0][0]
        elif gender == 'male' and english_male:
            return english_male
        elif english_female:
            return english_female
        elif voices.Count > 0:
            return voices.Item(0).Id
        return None
    except Exception as e:
        print(f"[TTS] 发现语音失败: {e}")
        return None


# ============================================================
#  Pyttsx3 后备方案（每实例创建新 engine）
# ============================================================

class _Pyttsx3TTS:
    """
    pyttsx3 后备 TTS：每次使用独立 engine 实例，
    避免跨线程死锁问题。不支持立即停止，但至少能正常说话。
    """

    def __init__(self, rate=180, volume=90, voice_id=None):
        self._engine = None
        self._speaking = False
        try:
            import pyttsx3
            self._engine = pyttsx3.init()
            self._engine.setProperty('rate', rate)
            self._engine.setProperty('volume', volume / 100.0)
            if voice_id:
                self._engine.setProperty('voice', voice_id)
        except Exception as e:
            print(f"[TTS] pyttsx3 初始化失败: {e}")
            self._engine = None

    def speak(self, text):
        """同步播报（会阻塞到说完为止）"""
        if not self._engine or not text:
            return False
        try:
            self._speaking = True
            self._engine.say(text)
            self._engine.runAndWait()  # 阻塞直到播完
            self._speaking = False
            return True
        except Exception as e:
            print(f"[TTS] pyttsx3 speak 失败: {e}")
            self._speaking = False
            return False

    def stop(self):
        """尝试停止（pyttsx3 stop 可能不可靠）"""
        if self._engine:
            try:
                self._engine.stop()
            except Exception:
                pass
        self._speaking = False

    @property
    def is_speaking(self):
        return self._speaking

    def release(self):
        if self._engine:
            try:
                self.stop()
            except Exception:
                pass
            try:
                del self._engine
            except Exception:
                pass
            self._engine = None


# ============================================================
#  SpeechEngine — 主入口
# ============================================================

class SpeechEngine:
    """语音引擎：负责语音识别(STT)和语音合成(TTS)"""

    # 无意义噪音白名单
    _NOISE_WORDS = {
        "嗯", "嗯。", "嗯？", "啊", "啊。", "哦", "哦。",
        "呃", "额", "哼", "呵", "嘻", "哈",
    }

    def __init__(self):
        # ---- 语音识别 ----
        self.recognizer = sr.Recognizer()
        self.microphone = sr.Microphone()
        # 基础阈值：适中值，校准后会根据实际环境调整
        self.recognizer.energy_threshold = 600
        # 开启动态阈值——让系统自适应环境噪音（校准后锁定）
        self.recognizer.dynamic_energy_threshold = True
        self.recognizer.pause_threshold = 0.5             # 停顿多久算一句话结束
        self.recognizer.phrase_threshold = 0.2             # 多短的声音算说话开始
        self.recognizer.non_speaking_duration = 0.25       # 非语音段容忍时长

        # ---- 一次性校准标志 ----
        self._calibrated = False          # 是否已完成环境噪音校准

        # ---- 语音合成（TTS引擎配置）----
        self.tts_engine_type = "local"   # "baidu"(百度在线) / "local"(SAPI5/pyttsx3)
        self.baidu_tts_client = None      # AipSpeech 实例(用于TTS)
        self._baidu_voice_id = 111        # 百度音色ID (默认度晓晓)
        self._tts_speed = 5               # 语速 0-15
        self._tts_pitch = 5               # 音调 0-15

        # ---- 本地 TTS 后备方案属性 ----
        self._voice_id = None             # SAPI5 voice ID
        self._use_sapi5 = False           # 运行时确定是否用 SAPI5
        self._current_tts = None          # 当前活跃的本地TTS实例
        self.is_speaking = False
        self._stop_requested = False
        self._speak_lock = threading.Lock()  # 防止并发 speak

        # 尝试发现 SAPI5 语音 ID（主线程，COM 已由 PyQt 初始化过）
        if _SAPI_AVAILABLE:
            self._voice_id = _discover_voice_id('female')

        # ---- 百度 STT (语音识别) ----
        self.speech_engine_type_stt = "baidu"
        self.baidu_stt_client = None

    # ---------- 公开 API：设置 ----------

    def set_baidu_credentials(self, app_id, api_key, secret_key):
        """设置百度智能云凭据（同时初始化STT和TTS客户端）"""
        client = None
        if app_id and api_key and secret_key:
            try:
                client = AipSpeech(app_id, api_key, secret_key)
                print(f"[TTS] 百度语音服务已启用")
            except Exception as e:
                print(f"[TTS] 百度客户端创建失败: {e}")
                client = None

        # 共享给STT
        self.baidu_stt_client = client
        if client:
            self.speech_engine_type_stt = "baidu"
        else:
            self.speech_engine_type_stt = "google"

        # 独立给TTS（TTS和STT可以独立使用）
        self.baidu_tts_client = client

    def set_tts_config(self, engine="baidu", voice_id=111, speed=5, pitch=5):
        """
        配置TTS引擎参数。
        
        :param engine:     "baidu"=百度在线TTS / "local"=SAPI5/pyttsx3
        :param voice_id:   百度音色ID (如111=度晓晓, 110=度小宁等)
        :param speed:      语速 0-15 (默认5)
        :param pitch:      音调 0-15 (默认5)
        """
        self.tts_engine_type = engine
        self._baidu_voice_id = voice_id
        self._tts_speed = max(0, min(15, speed))
        self._tts_pitch = max(0, min(15, pitch))
        tts_name = "百度在线TTS" if engine == "baidu" else "本地SAPI5"
        print(f"[TTS] 引擎={tts_name}, 音色={voice_id}, 语速={speed}, 音调={pitch}")

    @property
    def current_tts_info(self):
        """返回当前TTS配置信息（用于UI显示）"""
        return {
            "engine": self.tts_engine_type,
            "voice_id": self._baidu_voice_id,
            "speed": self._tts_speed,
            "pitch": self._tts_pitch,
        }

    def _set_voice(self, gender='female'):
        if _SAPI_AVAILABLE:
            self._voice_id = _discover_voice_id(gender)

    def set_voice_gender(self, gender):
        self._set_voice(gender)

    # ---------- TTS 核心方法 ----------

    @staticmethod
    def _clean_text(text):
        """清洗文本：去除 emoji、markdown 格式和多余空格"""
        # 去除 emoji
        emoji_pat = re.compile(
            "["
            "\U0001F600-\U0001F64F"
            "\U0001F300-\U0001F5FF"
            "\U0001F680-\U0001F6FF"
            "\U0001F900-\U0001F9FF"
            "\U0001FA00-\U0001FA6F"
            "\U0001FA70-\U0001FAFF"
            "\U00002600-\U000026FF"
            "\U00002700-\U000027BF"
            "\u200D\u200C\uFE0F\u20E3"
            "]",
            flags=re.UNICODE,
        )
        cleaned = emoji_pat.sub('', text)

        # 去除 Markdown 格式（SAPI5 会把 **、-、# 等读出来）
        cleaned = re.sub(r'\*\*([^*]+)\*\*', r'\1', cleaned)   # **粗体**
        cleaned = re.sub(r'\*([^*]+)\*', r'\1', cleaned)         # *斜体*
        cleaned = re.sub(r'^[-*+]\s+', '', cleaned, flags=re.M) # 列表标记 -
        cleaned = re.sub(r'^#{1,6}\s+', '', cleaned, flags=re.M) # 标题 #
        cleaned = re.sub(r'`[^`]+`', '', cleaned)                # 行内代码
        cleaned = re.sub(r'\[([^\]]+)\]\([^\)]+\)', r'\1', cleaned)  # [text](url) -> text
        cleaned = re.sub(r'\s{2,}', ' ', cleaned).strip()
        return cleaned

    _MAX_SPEAK_LENGTH = 300  # 播报最大字符数，超出则截断

    @staticmethod
    def _truncate_for_speech(text, max_len=None):
        """
        截断过长的播报文本。
        在句号、问号、感叹号等自然停顿处截断，保持语义完整。
        """
        if max_len is None:
            max_len = SpeechEngine._MAX_SPEAK_LENGTH
        if len(text) <= max_len:
            return text
        # 在 max_len 范围内找最后一个句末标点
        cutoff = text[:max_len]
        last_punct = max(cutoff.rfind('。'), cutoff.rfind('！'),
                         cutoff.rfind('？'), cutoff.rfind('；'),
                         cutoff.rfind('\n'), cutoff.rfind('，'))
        if last_punct > max_len * 0.5:  # 标点位置合理（至少超过一半）
            text = text[:last_punct + 1]
        else:
            text = text[:max_len]
        return text.strip() + "……以下内容省略"

    def stop(self):
        """停止当前正在进行的播放（连续试听/播报时自动打断）"""
        self._stop_requested = True
        self.is_speaking = False
        # 安全停止当前TTS实例的播放器
        if self._current_tts:
            try:
                self._current_tts.stop()
            except Exception:
                pass

    def speak(self, text, callback=None):
        """
        语音播报（自动选择最佳后端）。
        
        策略：
          1. 百度在线TTS（自然音色，支持多种音色）
          2. SAPI5 本地TTS（Windows原生，支持立即停止）
          3. pyttsx3 后备（兼容性好）
        
        连续调用时自动打断上一个正在进行的播放。
        """
        # 先停止上一个播放
        self.stop()

        with self._speak_lock:
            self._stop_requested = False
            self.is_speaking = True
            # 安全释放上一个实例
            if self._current_tts:
                try:
                    self._current_tts.stop()
                except Exception:
                    pass
                try:
                    self._current_tts.release()
                except Exception:
                    pass
                self._current_tts = None

        thread = threading.Thread(target=self._do_speak, args=(text, callback), daemon=True)
        thread.start()

    def _do_speak(self, text, callback):
        """在线程中执行播报（优先百度TTS → SAPI5 → pyttsx3）"""
        tts = None
        clean_text = self._clean_text(text)
        clean_text = self._truncate_for_speech(clean_text)
        use_sapi5 = False
        use_baidu = False

        print(f"正在播报: {text}")
        if clean_text != text:
            print(f"  (清洗后): {clean_text}")

        # ===== 优先：百度在线TTS（自然音色）=====
        if (self.tts_engine_type == "baidu"
                and self.baidu_tts_client is not None):
            try:
                baidu_tts = _BaiduTTS(
                    client=self.baidu_tts_client,
                    voice_id=self._baidu_voice_id,
                    speed=self._tts_speed,
                    pitch=self._tts_pitch,
                )
                if baidu_tts.is_available:
                    tts = baidu_tts
                    use_baidu = True
                    print(f"[TTS] 使用百度在线TTS (音色{self._baidu_voice_id})")
            except Exception as e:
                print(f"[TTS] 百度TTS初始化失败，回退本地引擎: {e}")

        # ===== 次选：SAPI5 本地TTS =====
        if tts is None and _SAPI_AVAILABLE and self._voice_id:
            try:
                com_ok = _init_com_in_thread()
                if com_ok:
                    tts = _Sapi5TTS(rate=200, volume=90, voice_id=self._voice_id)
                    if tts._voice is not None:
                        use_sapi5 = True
                        self._use_sapi5 = True
                        print("[TTS] 使用 SAPI5 后备方案")
                    else:
                        tts.release()
                        tts = None
            except Exception as e:
                print(f"[TTS] SAPI5 创建失败: {e}")
                if tts:
                    try: tts.release()
                    except Exception: pass
                    tts = None

        # ===== 最终后备：pyttsx3 =====
        if tts is None:
            try:
                import pyttsx3
                tts = _Pyttsx3TTS(rate=200, volume=90, voice_id=self._voice_id)
                if tts._engine is None:
                    tts = None
                else:
                    print("[TTS] 使用 pyttsx3 后备方案")
                    self._use_sapi5 = False
            except Exception as e:
                print(f"[TTS] pyttsx3 也失败了: {e}")
                tts = None

        # ===== 执行播报 =====
        if tts is None:
            print("[TTS] 所有 TTS 引擎均不可用！")
            self.is_speaking = False
            if callback:
                callback()
            return

        with self._speak_lock:
            self._current_tts = tts

        try:
            success = tts.speak(clean_text)

            # 百度TTS是同步阻塞播放的，到这里已说完
            # SAPI5异步模式需要轮询等待
            if use_baidu:
                pass  # 百度TTS.speak() 已阻塞到播放完毕
            elif use_sapi5:
                if success:
                    _speak_start = time.time()
                    _max_speak_time = max(60, len(clean_text) * 0.15)
                    while True:
                        if self._stop_requested:
                            print("[TTS] 收到停止指令...")
                            tts.stop()
                            break
                        elapsed = time.time() - _speak_start
                        if elapsed > _max_speak_time:
                            print(f"[TTS] 播放超时 ({_max_speak_time:.0f}秒)，强制退出")
                            tts.stop()
                            break
                        done = tts.wait_until_done(timeout_ms=100)
                        if done:
                            break
            # pyttsx3 是 runAndWait 同步阻塞

        except Exception as e:
            print(f"[TTS] 播放异常: {e}")
        finally:
            was_speaking = self.is_speaking
            self.is_speaking = False
            with self._speak_lock:
                if self._current_tts is tts:
                    self._current_tts = None
            # 清理 TTS 资源（仅 COM/SAPI5 需要）
            if use_sapi5 and hasattr(tts, 'release'):
                try: tts.release()
                except Exception: pass

            # 清理 COM
            if use_sapi5:
                try: _uninit_com()
                except Exception: pass

            # 正常结束才回调
            if was_speaking and not self._stop_requested and callback:
                callback()

    def stop_speaking(self):
        """停止语音播报（百度TTS / SAPI5 / pyttsx3 通用）"""
        self._stop_requested = True
        self.is_speaking = False
        if self._current_tts:
            print("[TTS] 正在停止播报...")
            try:
                self._current_tts.stop()
            except Exception as e:
                print(f"[TTS] stop 调用异常: {e}")

    # ---------- STT 核心方法 ----------

    def calibrate_once(self):
        """
        一次性环境噪音校准（在持续对话循环开始前调用一次即可）。
        策略：用动态阈值让系统自动适应环境，校准后锁定防止漂移。
        """
        if self._calibrated:
            return
        try:
            with self.microphone as source:
                print("[STT] 首次校准环境噪音 (0.3秒)...")
                # 校准时允许动态阈值自适应环境
                self.recognizer.dynamic_energy_threshold = True
                self.recognizer.adjust_for_ambient_noise(source, duration=0.3)
                # 安全下限：防止静音环境导致阈值过低
                if self.recognizer.energy_threshold < 150:
                    self.recognizer.energy_threshold = 150
                    print(f"[STT] 能量阈值过低，修正为: {self.recognizer.energy_threshold:.0f}")
                # 安全上限：防止嘈杂环境导致阈值过高听不到声音
                if self.recognizer.energy_threshold > 2000:
                    self.recognizer.energy_threshold = 1500
                    print(f"[STT] 能量阈值过高，修正为: {self.recognizer.energy_threshold:.0f}")
                # 校准完成后锁定，防止运行时被压低到接近0
                self.recognizer.dynamic_energy_threshold = False
                self._calibrated = True
                th = self.recognizer.energy_threshold
                print(f"[STT] 校准完成，锁定能量阈值: {th:.0f}（动态调整已关闭）")
        except Exception as e:
            print(f"[STT] 校准失败: {e}")
            # 即使失败也标记为已尝试，避免反复重试
            self._calibrated = True
            self.recognizer.dynamic_energy_threshold = False

    def reset_calibration(self):
        """重置校准状态（下次调用 listen 时会重新校准）"""
        self._calibrated = False
        # 重置到适中基础值（下次校准会自适应调整）
        self.recognizer.energy_threshold = 600
        self.recognizer.dynamic_energy_threshold = True

    def listen(self, timeout=5, phrase_time_limit=10, skip_calibration=True):
        """监听用户语音输入，返回识别文字或 None
        :param skip_calibration: True=跳过噪音校准（持续对话模式），False=强制校准
        """
        try:
            with self.microphone as source:
                if not self._calibrated or not skip_calibration:
                    print("正在调整噪音...")
                    self.recognizer.adjust_for_ambient_noise(source, duration=0.3)
                    self._calibrated = True
                else:
                    # 持续对话模式：跳过校准，直接监听（零延迟）
                    print("[STT] 跳过校准，直接开始监听...")
                print("请说话...")

                audio = self.recognizer.listen(
                    source,
                    timeout=timeout,
                    phrase_time_limit=phrase_time_limit,
                )

            # 音频能量预检
            try:
                raw = audio.get_raw_data(convert_rate=16000, convert_width=2)
                rms = audioop.rms(raw, 2)
                if rms < 300:
                    print("音频能量过低，忽略（可能为环境噪音）")
                    return None
            except Exception:
                pass

            # 送入识别引擎
            try:
                print(f"正在识别 ({self.speech_engine_type_stt})...")

                if self.speech_engine_type_stt == "baidu":
                    text = self._recognize_with_baidu(audio)
                else:
                    text = self.recognizer.recognize_google(audio, language='zh-CN')

                if text:
                    stripped = text.strip()
                    # 过滤无意义噪音
                    if len(stripped) <= 1 or stripped in self._NOISE_WORDS:
                        print(f"忽略无内容: {text}")
                        return None
                    print(f"识别结果: {text}")
                    return text
                else:
                    print("无法识别语音内容")
                    return None

            except sr.UnknownValueError:
                print("无法识别语音(Google)")
                return None
            except sr.RequestError as e:
                print(f"语音识别服务错误: {e}")
                return None

        except sr.WaitTimeoutError:
            print("监听超时")
            return None
        except Exception as e:
            err_str = str(e).lower()
            # 检测连接断开/重置类错误，重建麦克风资源
            if any(kw in err_str for kw in ["connection", "reset", "aborted", "远程", "10054"]):
                print(f"[STT] 连接异常，重建麦克风: {e}")
                try:
                    self.microphone = sr.Microphone()
                    self._calibrated = False  # 重新校准
                    self.recognizer.energy_threshold = 600
                    self.recognizer.dynamic_energy_threshold = True
                except Exception as re_err:
                    print(f"[STT] 麦克风重建失败: {re_err}")
            else:
                print(f"监听错误: {e}")
            return None

    def _recognize_with_baidu(self, audio_data):
        """百度 STT"""
        if not self.baidu_stt_client:
            raise Exception("百度客户端未初始化")
        raw = audio_data.get_raw_data(convert_rate=16000, convert_width=2)
        result = self.baidu_stt_client.asr(raw, 'pcm', 16000, {'dev_pid': 1537})
        if 'result' in result and result['result']:
            return result['result'][0]
        elif 'error_code' in result and result['error_code'] != 0:
            raise Exception(f"百度错误 {result['error_code']}: {result.get('error_msg')}")
        return None
