# modules/video_player.py - 视频播放器模块

import cv2
import numpy as np
from PyQt5.QtCore import QThread, pyqtSignal, Qt
from PyQt5.QtGui import QImage, QPixmap
import os


# ===== 视频播放参数配置 =====
MAX_WIDTH = 960            # 最大渲染宽度（超过此值自动缩放，避免4K/大视频卡顿）
MAX_HEIGHT = 720           # 最大渲染高度
MIN_FILE_SIZE_MB = 0.1     # 最小文件大小(MB)，小于则视为异常
WARN_FILE_SIZE_MB = 500    # 警告阈值(MB)，超过提示用户可能较慢

class VideoPlayer(QThread):
    """
    视频播放器线程 — 支持大文件自动缩放、文件校验、错误反馈
    
    处理策略：
      - 文件大小超过 WARN_FILE_SIZE_MB 时打印警告但仍尝试播放
      - 视频分辨率超过 MAX_WIDTH x MAX_HEIGHT 时自动等比缩放
      - 所有错误通过 error_signal 发送，UI层可捕获展示
    """

    # 信号：发送视频帧（已缩放至合理尺寸）
    frame_signal = pyqtSignal(QImage)
    # 信号：播放结束
    finished_signal = pyqtSignal()
    # 信号：错误/警告信息（供UI层显示给用户）
    error_signal = pyqtSignal(str)

    def __init__(self, video_path=""):
        """
        初始化视频播放器
        :param video_path: 视频文件路径
        """
        super().__init__()
        self.video_path = video_path
        self.is_playing = False
        self.cap = None

    def set_video(self, video_path):
        """设置视频文件"""
        self.video_path = video_path

    def _get_file_size_mb(self):
        """获取视频文件大小(MB)，文件不存在返回0"""
        try:
            if self.video_path and os.path.exists(self.video_path):
                return os.path.getsize(self.video_path) / (1024 * 1024)
        except Exception:
            pass
        return 0

    def _scale_frame(self, frame):
        """
        将帧缩放到 MAX_WIDTH x MAX_HEIGHT 以内（保持宽高比）。
        避免高分辨率(如1080p/4K)视频在QLabel中渲染时卡顿。
        :param frame: OpenCV BGR格式图像
        :return: 缩放后的帧
        """
        h, w = frame.shape[:2]

        # 已在限制范围内，无需缩放
        if w <= MAX_WIDTH and h <= MAX_HEIGHT:
            return frame

        # 按较长边计算缩放比例
        scale_w = MAX_WIDTH / w
        scale_h = MAX_HEIGHT / h
        scale = min(scale_w, scale_h)

        new_w = int(w * scale)
        new_h = int(h * scale)

        return cv2.resize(frame, (new_w, new_h), interpolation=cv2.INTER_AREA)

    def run(self):
        """播放视频（带文件校验和自动缩放）"""

        # ---- 1. 路径和存在性检查 ----
        if not self.video_path:
            self.error_signal.emit("未设置视频文件，请在系统设置中选择视频")
            self._send_placeholder("请先选择视频文件\n系统设置 → 选择视频")
            return

        if not os.path.exists(self.video_path):
            self.error_signal.emit(f"视频文件不存在: {self.video_path}")
            self._send_placeholder(f"视频文件不存在\n{os.path.basename(self.video_path)}")
            return

        # ---- 2. 文件大小检查 ----
        file_size_mb = self._get_file_size_mb()

        if file_size_mb < MIN_FILE_SIZE_MB:
            self.error_signal.emit(f"视频文件异常小 ({file_size_mb:.1f}MB)，可能已损坏")
            self._send_placeholder("视频文件可能损坏\n请重新选择视频")
            return

        if file_size_mb > WARN_FILE_SIZE_MB:
            msg = f"视频较大 ({file_size_mb:.0f}MB)，首次加载可能需要几秒钟..."
            print(f"[VideoPlayer] 警告: {msg}")
            self.error_signal.emit(msg)

        # ---- 3. 打开视频 ----
        self.cap = cv2.VideoCapture(self.video_path)
        self.is_playing = True

        if not self.cap.isOpened():
            self.error_signal.emit("无法打开视频文件，可能编码不支持或文件损坏")
            self._send_placeholder("无法打开视频\n可能编码不支持或文件已损坏")
            return

        # ---- 4. 获取视频信息 ----
        fps = self.cap.get(cv2.CAP_PROP_FPS)
        total_frames = int(self.cap.get(cv2.CAP_PROP_FRAME_COUNT))
        vid_w = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        vid_h = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

        # 帧率控制（最低5fps避免卡成幻灯片，最高30fps节省性能）
        delay = int(1000 / fps) if fps >= 5 else int(1000 / 30)
        delay = max(min(delay, 100), 33)  # clamp: 10fps ~ 30fps

        print(f"[VideoPlayer] 视频: {os.path.basename(self.video_path)} | "
              f"尺寸: {vid_w}x{vid_h} | FPS: {fps:.1f} | "
              f"帧数: {total_frames} | 大小: {file_size_mb:.1f}MB")

        # 是否需要缩放标志
        need_scale = (vid_w > MAX_WIDTH or vid_h > MAX_HEIGHT)
        if need_scale:
            print(f"[VideoPlayer] 分辨率过高({vid_w}x{vid_h})，"
                  f"将自动缩放至 {MAX_WIDTH}x{MAX_HEIGHT} 以内")

        # ---- 5. 循环读取帧 ----
        while self.is_playing:
            ret, frame = self.cap.read()

            if not ret:
                # 视频结束或读取失败，循环从头播放
                self.cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                continue

            # 自动缩放（仅当原始分辨率超标时）
            if need_scale:
                frame = self._scale_frame(frame)

            # BGR → RGB（PyQt QImage 需要 RGB）
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            h, w, ch = frame_rgb.shape
            bytes_per_line = ch * w

            # 构造 QImage（注意：frame_rgb.data 必须在 qt_image 使用期间有效）
            qt_image = QImage(frame_rgb.data, w, h, bytes_per_line, QImage.Format_RGB888).copy()

            # 发送帧信号到 UI
            self.frame_signal.emit(qt_image)

            # 控制播放速度
            self.msleep(delay)

        # ---- 6. 清理 ----
        self.cap.release()
        self.finished_signal.emit()
        
    def _send_placeholder(self, text="视频播放异常\n请检查文件"):
        """
        发送占位图像（错误/空状态时使用）
        :param text: 显示在占位图上的文字
        """
        # 创建深灰色背景的占位图
        placeholder = np.zeros((480, 640, 3), dtype=np.uint8)
        placeholder[:] = (45, 45,48)

        h, w, ch = placeholder.shape
        bytes_per_line = ch * w
        qt_image = QImage(placeholder.data, w, h, bytes_per_line, QImage.Format_RGB888).copy()
        self.frame_signal.emit(qt_image)

    def stop(self):
        """停止播放"""
        self.is_playing = False
        if self.cap:
            self.cap.release()