# modules/wake_word.py - 唤醒词检测模块

import speech_recognition as sr
import threading
import time
import audioop
from aip import AipSpeech

# 拼音映射表（常用汉字 → 拼音）
_PINYIN_MAP = {
    "小": "xiao", "智": "zhi", "志": "zhi", "治": "zhi", "制": "zhi",
    "知": "zhi", "之": "zhi", "子": "zi", "紫": "zi", "字": "zi",
    "助": "zhu", "主": "zhu", "猪": "zhu", "珠": "zhu",
    "杰": "jie", "洁": "jie", "姐": "jie", "解": "jie",
    "天": "tian", "添": "tian", "甜": "tian",
    "爱": "ai", "艾": "ai", "哎": "ai",
    "嘿": "hei", "黑": "hei", "嗨": "hai",
    "喂": "wei", "位": "wei", "卫": "wei",
}


def _to_pinyin_fuzzy(text):
    """将中文文本转为模糊拼音（用于同音字匹配）"""
    result = []
    for char in text:
        if char in _PINYIN_MAP:
            result.append(_PINYIN_MAP[char])
        elif '\u4e00' <= char <= '\u9fff':
            result.append(char)  # 未收录的汉字保留原样
        else:
            result.append(char.lower())
    return ''.join(result)


class WakeWordDetector:
    """唤醒词检测器"""

    # 无意义短句白名单：这些是常见误识别，直接忽略
    _NOISE_PATTERNS = {"嗯", "嗯。", "嗯？", "啊", "啊。", "哦", "哦。",
                       "呃", "额", "哼", "呵", "嘻", "哈", "嘿"}

    def __init__(self, wake_word="小智", callback=None):
        self.wake_word = wake_word.lower()
        self.callback = callback
        self.is_listening = False
        self.recognizer = sr.Recognizer()
        self.microphone = sr.Microphone()

        # ===== 唤醒词监听参数（抗噪优化）=====
        # energy_threshold: 基础值，每次校准后会自适应调整
        self.recognizer.energy_threshold = 600

        # 开启动态阈值——校准期间自适应环境，校准后锁定
        self.recognizer.dynamic_energy_threshold = True

        # pause_threshold: 需要较长停顿才判定说完（避免把短促噪音当句子）
        self.recognizer.pause_threshold = 0.6

        # phrase_threshold: 声音必须持续足够久才算说话开始
        self.recognizer.phrase_threshold = 0.3

        # non_speaking_duration: 有效静音段
        self.recognizer.non_speaking_duration = 0.4

        # 百度语音识别
        self.baidu_client = None
        self.speech_engine_type = "baidu"

    def set_baidu_credentials(self, app_id, api_key, secret_key):
        if app_id and api_key and secret_key:
            self.baidu_client = AipSpeech(app_id, api_key, secret_key)
            self.speech_engine_type = "baidu"
        else:
            self.baidu_client = None
            self.speech_engine_type = "google"

    def set_wake_word(self, wake_word):
        self.wake_word = wake_word.lower()

    def start_listening(self):
        self.is_listening = True
        thread = threading.Thread(target=self._listen_loop, daemon=True)
        thread.start()

    def stop_listening(self):
        self.is_listening = False

    def _recognize_with_baidu(self, audio_data):
        raw_data = audio_data.get_raw_data(convert_rate=16000, convert_width=2)
        result = self.baidu_client.asr(raw_data, 'pcm', 16000, {'dev_pid': 1537})
        if 'result' in result and result['result']:
            return result['result'][0]
        return None

    @staticmethod
    def _audio_rms(audio_data):
        """计算音频 RMS 能量值（用于预判是否为有效人声）"""
        try:
            raw = audio_data.get_raw_data(convert_rate=16000, convert_width=2)
            rms = audioop.rms(raw, 2)
            return rms
        except Exception:
            return 0

    @staticmethod
    def _is_noise_text(text):
        """判断识别结果是否为无意义噪音"""
        if not text or len(text.strip()) <= 1:
            return True
        stripped = text.strip()
        # 纯单字或纯语气词
        if stripped in WakeWordDetector._NOISE_PATTERNS:
            return True
        return False

    def _listen_loop(self):
        print(f"[唤醒] 开始监听: 「{self.wake_word}」(能量阈值={self.recognizer.energy_threshold})")

        consecutive_errors = 0
        MAX_CONSECUTIVE_ERRORS = 3

        while self.is_listening:
            try:
                with self.microphone as source:
                    # 噪音校准（仅首次或间隔较长时间后）
                    self.recognizer.adjust_for_ambient_noise(source, duration=0.3)
                    # 安全范围：防止阈值被压到接近0或过高
                    if self.recognizer.energy_threshold < 150:
                        self.recognizer.energy_threshold = 150
                    elif self.recognizer.energy_threshold > 2000:
                        self.recognizer.energy_threshold = 1500
                    # 校准后锁定动态阈值，防止运行时漂移
                    self.recognizer.dynamic_energy_threshold = False
                    print(f"等待唤醒词... (阈值={self.recognizer.energy_threshold:.0f})")
                    audio = self.recognizer.listen(
                        source, timeout=None, phrase_time_limit=3
                    )
                # 成功识别，重置错误计数
                consecutive_errors = 0

                # ---- 预检1: 音频能量过滤 ----
                # RMS < 200 说明几乎没有有效声音，大概率是电子噪声
                rms = self._audio_rms(audio)
                if rms < 200:
                    continue

                # ---- 预检2: 送入识别引擎 ----
                try:
                    if self.speech_engine_type == "baidu" and self.baidu_client:
                        text = self._recognize_with_baidu(audio)
                    else:
                        text = self.recognizer.recognize_google(
                            audio, language='zh-CN'
                        )

                    if not text:
                        continue

                    # ---- 预检3: 过滤无意义噪音文本 ----
                    if self._is_noise_text(text):
                        continue

                    # 有意义的识别结果才打印
                    print(f"识别到: {text}")

                    # 检查唤醒词（模糊匹配：精确匹配 + 拼音匹配）
                    text_lower = text.lower()
                    is_wake = False
                    if self.wake_word in text_lower:
                        is_wake = True
                    else:
                        # 模糊拼音匹配：将唤醒词和识别结果都转拼音再比较
                        wake_pinyin = _to_pinyin_fuzzy(self.wake_word)
                        text_pinyin = _to_pinyin_fuzzy(text_lower)
                        if wake_pinyin in text_pinyin:
                            is_wake = True

                    if is_wake:
                        print("检测到唤醒词！")
                        if self.callback:
                            self.callback()

                except sr.UnknownValueError:
                    pass
                except sr.RequestError as e:
                    print(f"[唤醒] 识别服务错误: {e}")
                    time.sleep(2)

            except AssertionError:
                print("[唤醒] 重新初始化麦克风...")
                self.microphone = sr.Microphone()
            except Exception as e:
                err_str = str(e).lower()
                consecutive_errors += 1
                # 检测到连接断开类错误（百度 STT 常见）
                if any(kw in err_str for kw in ["connection", "reset", "aborted", "远程"]):
                    print(f"[唤醒] 网络连接异常 (第{consecutive_errors}次): {e}")
                    if consecutive_errors >= MAX_CONSECUTIVE_ERRORS:
                        print("[唤醒] 连续多次连接失败，重建麦克风...")
                        try:
                            self.microphone = sr.Microphone()
                            consecutive_errors = 0
                            # 重置到适中值，允许下次校准自适应
                            self.recognizer.energy_threshold = 600
                            self.recognizer.dynamic_energy_threshold = True
                        except Exception:
                            pass
                    else:
                        time.sleep(1)  # 短暂等待后重试
                else:
                    print(f"[唤醒] 监听错误: {e}")
                    time.sleep(1)